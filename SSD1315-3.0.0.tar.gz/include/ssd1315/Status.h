/**
 * @file Status.h
 * @brief Error handling types for SSD1315 OLED driver library.
 *
 * Provides a lightweight, zero-allocation error model. All error messages
 * are static string literals. Never allocate error strings dynamically.
 */

#pragma once

#include <cstddef>
#include <stdint.h>

namespace SSD1315 {

/**
 * @brief Supported controller initialization/profile contract.
 *
 * The driver currently implements and validates the SSD1315 command profile.
 * SSD1306-like panels may accept many of the same commands, but they are not
 * represented by this enum until SSD1306-specific command guards and hardware
 * validation exist.
 */
enum class ControllerProfile : uint8_t {
  SSD1315 = 0  ///< SSD1315 controller profile; includes SSD1315 SET_IREF.
};

/**
 * @brief Error code enumeration for SSD1315 driver operations.
 *
 * Covers all common embedded error scenarios and I2C-specific failures.
 * When using transport callbacks, map third-party errors to the most
 * appropriate Err code and store the original value in Status::detail.
 */
enum class Err : uint16_t {
  OK = 0,             ///< Success, no error

  // Configuration errors
  INVALID_CONFIG,     ///< Invalid configuration parameter (null pointer, out of range)
  INVALID_DIMENSIONS, ///< Invalid width/height (height must be 16..64, multiple of 8)
  INVALID_PAGE_COUNT, ///< pageBufferPages out of valid range [1..totalPages]

  // State errors
  NOT_INITIALIZED,    ///< Library not initialized; begin() not called or failed
  STATE_ERROR,        ///< Invalid state for requested operation
  BUSY,               ///< Transient operation conflict; try again later
  PANEL_NOT_READY,    ///< Reserved legacy code; normal panel delay reports IN_PROGRESS

  // I2C transport errors
  I2C_NACK_ADDR,      ///< I2C address not acknowledged (device not found)
  I2C_NACK_DATA,      ///< I2C data byte not acknowledged
  I2C_TIMEOUT,        ///< I2C operation timed out
  I2C_BUS_ERROR,      ///< I2C bus error (arbitration lost, etc.)
  I2C_BUS = I2C_BUS_ERROR, ///< Compatibility alias for I2C bus error

  // General errors
  TIMEOUT,            ///< Generic operation timeout
  BUFFER_OVERFLOW,    ///< Buffer size exceeded
  UNSUPPORTED,        ///< Operation not supported (e.g., read in I2C mode)
  INTERNAL_ERROR,     ///< Internal logic error (bug in library code)
  DEVICE_NOT_FOUND,   ///< Device not present at expected address
  IN_PROGRESS,        ///< Operation in progress (not an error)
  BUFFER_TOO_SMALL,   ///< Caller-provided buffer is smaller than required
  DRIVER_OFFLINE      ///< Latched driver fault; call recover()
};

/**
 * @brief Operation result with error details.
 *
 * Returned by all fallible operations. Check with ok() or inspect code/msg.
 *
 * @note The msg field MUST point to a static string literal. Never assign
 *       dynamically allocated strings. This ensures zero heap allocation
 *       in error paths and safe usage across function boundaries.
 *
 * Example:
 * @code
 * Status st = display.begin(config);
 * if (!st.ok()) {
 *   handleDisplayError(st.code, st.detail, st.msg);
 * }
 * @endcode
 */
struct Status {
  Err code = Err::OK;       ///< Error category
  int32_t detail = 0;       ///< Transport/vendor-specific error code (optional)
  const char* msg = "";     ///< Human-readable message (STATIC STRING ONLY)

  /**
   * @brief Default constructor - creates OK status.
   */
  constexpr Status() : code(Err::OK), detail(0), msg("") {}

  /**
   * @brief Constructor with all fields.
   * @param c Error code
   * @param d Detail/vendor error code
   * @param m Static string message
   */
  constexpr Status(Err c, int32_t d, const char* m) : code(c), detail(d), msg(m) {}

  /**
   * @brief Convenience constructor with code and message.
   * @param c Error code
   * @param m Static string message
   */
  constexpr Status(Err c, const char* m) : code(c), detail(0), msg(m) {}

  /**
   * @brief Check if operation succeeded.
   * @return true if code == Err::OK
   */
  constexpr bool ok() const { return code == Err::OK; }

  /**
   * @brief Check whether this status matches a specific code.
   * @param err Error code to compare against.
   * @return true if code == err
   */
  constexpr bool is(Err err) const { return code == err; }

  /**
   * @brief Check if operation is still in progress (not an error).
   * @return true if code == Err::IN_PROGRESS
   */
  constexpr bool inProgress() const { return code == Err::IN_PROGRESS; }

  /**
   * @brief Implicit boolean conversion for success checks.
   * @return true if operation succeeded
   */
  explicit constexpr operator bool() const { return ok(); }

  /**
   * @brief Create a success Status.
   * @return Status with Err::OK
   */
  static constexpr Status Ok() { return Status(Err::OK, 0, ""); }

  /**
   * @brief Create an error Status with message.
   * @param c Error code
   * @param m Static string message
   * @return Status with error
   */
  static constexpr Status Error(Err c, const char* m) { return Status(c, 0, m); }

  /**
   * @brief Create an error Status with message and detail.
   * @param c Error code
   * @param d Detail/vendor error code
   * @param m Static string message
   * @return Status with error
   */
  static constexpr Status Error(Err c, int32_t d, const char* m) {
    return Status(c, d, m);
  }

  /**
   * @brief Create an error Status with message and detail.
   * @param c Error code
   * @param m Static string message
   * @param d Detail/vendor error code
   * @return Status with error
   */
  static constexpr Status Error(Err c, const char* m, int32_t d) {
    return Status(c, d, m);
  }

};

/**
 * @brief Create a success Status.
 * @return Status with Err::OK
 */
inline constexpr Status Ok() { return Status::Ok(); }

/**
 * @brief Create an error Status with message.
 * @param c Error code
 * @param m Static string message
 * @return Status with error
 */
inline constexpr Status Error(Err c, const char* m) { return Status::Error(c, m); }

/**
 * @brief Create an error Status with message and detail.
 * @param c Error code
 * @param d Detail/vendor error code
 * @param m Static string message
 * @return Status with error
 */
inline constexpr Status Error(Err c, int32_t d, const char* m) {
  return Status::Error(c, d, m);
}

/**
 * @brief Create an error Status with message and detail.
 * @param c Error code
 * @param m Static string message
 * @param d Detail/vendor error code
 * @return Status with error
 */
inline constexpr Status Error(Err c, const char* m, int32_t d) {
  return Status::Error(c, m, d);
}

/**
 * @brief Driver health indicator (NOT a lifecycle state machine).
 *
 * DriverState reflects the outcome of recent I2C transactions. It is NOT
 * a lifecycle FSM - there are no time-based transitions, no background
 * checks, and no automatic state changes without actual I2C activity.
 *
 * State changes occur ONLY when:
 * - An I2C transaction succeeds (→ READY)
 * - An I2C transaction fails (→ DEGRADED or OFFLINE based on threshold)
 * - begin() or end() is called (→ UNINIT or READY)
 *
 * IMPORTANT: OFFLINE is latched for normal public operations. Once OFFLINE,
 * those operations return BUSY without touching I2C until the application calls
 * recover(). Explicit diagnostics/recovery APIs may still use I2C.
 */
enum class DriverState : uint8_t {
  UNINIT,    ///< Driver not initialized or init in progress.
             ///< This is a structural state, not a health state.
             ///< During init (when _initialized==true): first I2C success → READY,
             ///< first I2C failure → DEGRADED (or OFFLINE if threshold is 1).

  READY,     ///< Last I2C transaction succeeded. Device is healthy.
             ///< This is the normal operating state.

  DEGRADED,  ///< 1 to (N-1) consecutive failures occurred.
             ///< Device may still respond - worth retrying.
             ///< Success before OFFLINE returns READY. Nth failure -> OFFLINE.

  OFFLINE    ///< N or more consecutive failures occurred.
             ///< Device assumed missing or unresponsive.
             ///< Application should call recover() or investigate.
};

/**
 * @brief Public snapshot phase for the framebuffer flush job.
 *
 * Each command or data transaction is one instruction. Column and page address
 * setup are represented separately so callers can verify instruction budgets.
 */
enum class FlushPhase : uint8_t {
  IDLE,           ///< No flush job is active.
  SET_COL_ADDR,   ///< Next instruction sets the column address window.
  SET_PAGE_ADDR,  ///< Next instruction sets the page address window.
  SEND_DATA,      ///< Next instruction sends one bounded data chunk.
  DONE,           ///< Flush completed and awaits final accounting.
  ERROR           ///< Flush failed and awaits final accounting.
};

/**
 * @brief Snapshot of the current flush job without performing I2C.
 */
struct FlushStatus {
  FlushPhase phase = FlushPhase::IDLE;  ///< Current flush phase.
  bool inProgress = false;              ///< true while command/data instructions remain.
  uint8_t dirtyPages = 0;               ///< Dirty page bitmask.
  uint8_t currentPage = 0;              ///< Physical page currently being flushed.
  uint8_t endPage = 0;                  ///< Last page considered by the active job.
  uint16_t currentColumn = 0;           ///< Next data column for SEND_DATA.
  uint8_t minColumn = 0;                ///< Current page dirty-window minimum column.
  uint8_t maxColumn = 0;                ///< Current page dirty-window maximum column.
  Status lastError = Status::Ok();      ///< Most recent flush error, if any.
};

/// @brief Snapshot of configuration and runtime state without performing I2C.
struct SettingsSnapshot {
  bool initialized = false;
  DriverState state = DriverState::UNINIT;
  ControllerProfile controllerProfile = ControllerProfile::SSD1315;
  uint8_t i2cAddress = 0x3C;
  uint32_t i2cTimeoutMs = 25;
  uint8_t offlineThreshold = 3;
  bool hasNowMsHook = false;
  bool hasCooperativeYieldHook = false;
  bool hasI2cWriteReadHook = false;

  uint8_t width = 128;
  uint8_t height = 64;
  uint8_t pageBufferPages = 8;
  uint8_t totalPages = 8;
  bool pageBufferMode = false;
  bool sleeping = true;
  bool allPixelsOn = false;
  uint8_t userPageCount = 1;
  uint8_t activeUserPage = 0;
  uint8_t currentPageIndex = 0;
  bool pageIterationActive = false;
  uint32_t byteBudgetPerTick = 128;
  uint32_t flushTimeoutMs = 1000;
  uint32_t displayOnDelayMs = 100;
  bool clearOnBegin = true;
  bool clearOnRecover = true;
  uint32_t inactivitySleepMs = 0;
  uint32_t pageCycleMs = 0;
  bool flipX = false;
  bool flipY = false;
  bool invert = false;
  uint8_t contrast = 0x7F;
  uint8_t comPins = 0x12;
  uint8_t chargePumpVoltage = 0x14;
  uint8_t iref = 0x10;
  uint8_t vcomh = 0x20;
  uint8_t clockDivide = 1;
  uint8_t oscFrequency = 8;
  uint8_t prechargePhase1 = 2;
  uint8_t prechargePhase2 = 2;
  bool scrollActive = false;
  bool hasExternalBuffer = false;
  bool ownsBuffer = false;
  size_t bufferSize = 0;
  uint8_t dirtyPages = 0;
  bool flushing = false;
  bool controlStateDirty = false;
  Status controlStateError = Status::Ok();

  uint32_t lastOkMs = 0;
  uint32_t lastErrorMs = 0;
  uint8_t consecutiveFailures = 0;
  uint32_t totalFailures = 0;
  uint32_t totalSuccess = 0;
  Status lastError = Status::Ok();
};

}  // namespace SSD1315
