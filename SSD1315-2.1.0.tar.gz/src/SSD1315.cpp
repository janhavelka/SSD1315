/**
 * @file SSD1315.cpp
 * @brief SSD1315 OLED display driver implementation.
 */

#include "ssd1315/SSD1315.h"

#include <new>       // std::nothrow
#include <string.h>  // memset

namespace SSD1315 {

namespace {

class ScopedOfflineI2cAllowance {
public:
  explicit ScopedOfflineI2cAllowance(bool& flag, bool allow) : _flag(flag), _old(flag) {
    _flag = allow;
  }

  ~ScopedOfflineI2cAllowance() {
    _flag = _old;
  }

  ScopedOfflineI2cAllowance(const ScopedOfflineI2cAllowance&) = delete;
  ScopedOfflineI2cAllowance& operator=(const ScopedOfflineI2cAllowance&) = delete;

private:
  bool& _flag;
  bool _old;
};

}  // namespace

// ============================================================================
// Built-in 5x7 font (ASCII 32-126)
// ============================================================================

// Font data: 5 bytes per character, each byte is a column, LSB = top
// Character cell is 6x8 (5x7 glyph + 1 column spacing + 1 row spacing)
static const uint8_t FONT_5X7[] = {
    0x00, 0x00, 0x00, 0x00, 0x00,  // 32 ' '
    0x00, 0x00, 0x5F, 0x00, 0x00,  // 33 '!'
    0x00, 0x07, 0x00, 0x07, 0x00,  // 34 '"'
    0x14, 0x7F, 0x14, 0x7F, 0x14,  // 35 '#'
    0x24, 0x2A, 0x7F, 0x2A, 0x12,  // 36 '$'
    0x23, 0x13, 0x08, 0x64, 0x62,  // 37 '%'
    0x36, 0x49, 0x55, 0x22, 0x50,  // 38 '&'
    0x00, 0x05, 0x03, 0x00, 0x00,  // 39 '''
    0x00, 0x1C, 0x22, 0x41, 0x00,  // 40 '('
    0x00, 0x41, 0x22, 0x1C, 0x00,  // 41 ')'
    0x08, 0x2A, 0x1C, 0x2A, 0x08,  // 42 '*'
    0x08, 0x08, 0x3E, 0x08, 0x08,  // 43 '+'
    0x00, 0x50, 0x30, 0x00, 0x00,  // 44 ','
    0x08, 0x08, 0x08, 0x08, 0x08,  // 45 '-'
    0x00, 0x60, 0x60, 0x00, 0x00,  // 46 '.'
    0x20, 0x10, 0x08, 0x04, 0x02,  // 47 '/'
    0x3E, 0x51, 0x49, 0x45, 0x3E,  // 48 '0'
    0x00, 0x42, 0x7F, 0x40, 0x00,  // 49 '1'
    0x42, 0x61, 0x51, 0x49, 0x46,  // 50 '2'
    0x21, 0x41, 0x45, 0x4B, 0x31,  // 51 '3'
    0x18, 0x14, 0x12, 0x7F, 0x10,  // 52 '4'
    0x27, 0x45, 0x45, 0x45, 0x39,  // 53 '5'
    0x3C, 0x4A, 0x49, 0x49, 0x30,  // 54 '6'
    0x01, 0x71, 0x09, 0x05, 0x03,  // 55 '7'
    0x36, 0x49, 0x49, 0x49, 0x36,  // 56 '8'
    0x06, 0x49, 0x49, 0x29, 0x1E,  // 57 '9'
    0x00, 0x36, 0x36, 0x00, 0x00,  // 58 ':'
    0x00, 0x56, 0x36, 0x00, 0x00,  // 59 ';'
    0x00, 0x08, 0x14, 0x22, 0x41,  // 60 '<'
    0x14, 0x14, 0x14, 0x14, 0x14,  // 61 '='
    0x41, 0x22, 0x14, 0x08, 0x00,  // 62 '>'
    0x02, 0x01, 0x51, 0x09, 0x06,  // 63 '?'
    0x32, 0x49, 0x79, 0x41, 0x3E,  // 64 '@'
    0x7E, 0x11, 0x11, 0x11, 0x7E,  // 65 'A'
    0x7F, 0x49, 0x49, 0x49, 0x36,  // 66 'B'
    0x3E, 0x41, 0x41, 0x41, 0x22,  // 67 'C'
    0x7F, 0x41, 0x41, 0x22, 0x1C,  // 68 'D'
    0x7F, 0x49, 0x49, 0x49, 0x41,  // 69 'E'
    0x7F, 0x09, 0x09, 0x01, 0x01,  // 70 'F'
    0x3E, 0x41, 0x41, 0x51, 0x32,  // 71 'G'
    0x7F, 0x08, 0x08, 0x08, 0x7F,  // 72 'H'
    0x00, 0x41, 0x7F, 0x41, 0x00,  // 73 'I'
    0x20, 0x40, 0x41, 0x3F, 0x01,  // 74 'J'
    0x7F, 0x08, 0x14, 0x22, 0x41,  // 75 'K'
    0x7F, 0x40, 0x40, 0x40, 0x40,  // 76 'L'
    0x7F, 0x02, 0x04, 0x02, 0x7F,  // 77 'M'
    0x7F, 0x04, 0x08, 0x10, 0x7F,  // 78 'N'
    0x3E, 0x41, 0x41, 0x41, 0x3E,  // 79 'O'
    0x7F, 0x09, 0x09, 0x09, 0x06,  // 80 'P'
    0x3E, 0x41, 0x51, 0x21, 0x5E,  // 81 'Q'
    0x7F, 0x09, 0x19, 0x29, 0x46,  // 82 'R'
    0x46, 0x49, 0x49, 0x49, 0x31,  // 83 'S'
    0x01, 0x01, 0x7F, 0x01, 0x01,  // 84 'T'
    0x3F, 0x40, 0x40, 0x40, 0x3F,  // 85 'U'
    0x1F, 0x20, 0x40, 0x20, 0x1F,  // 86 'V'
    0x7F, 0x20, 0x18, 0x20, 0x7F,  // 87 'W'
    0x63, 0x14, 0x08, 0x14, 0x63,  // 88 'X'
    0x03, 0x04, 0x78, 0x04, 0x03,  // 89 'Y'
    0x61, 0x51, 0x49, 0x45, 0x43,  // 90 'Z'
    0x00, 0x00, 0x7F, 0x41, 0x41,  // 91 '['
    0x02, 0x04, 0x08, 0x10, 0x20,  // 92 '\'
    0x41, 0x41, 0x7F, 0x00, 0x00,  // 93 ']'
    0x04, 0x02, 0x01, 0x02, 0x04,  // 94 '^'
    0x40, 0x40, 0x40, 0x40, 0x40,  // 95 '_'
    0x00, 0x01, 0x02, 0x04, 0x00,  // 96 '`'
    0x20, 0x54, 0x54, 0x54, 0x78,  // 97 'a'
    0x7F, 0x48, 0x44, 0x44, 0x38,  // 98 'b'
    0x38, 0x44, 0x44, 0x44, 0x20,  // 99 'c'
    0x38, 0x44, 0x44, 0x48, 0x7F,  // 100 'd'
    0x38, 0x54, 0x54, 0x54, 0x18,  // 101 'e'
    0x08, 0x7E, 0x09, 0x01, 0x02,  // 102 'f'
    0x08, 0x14, 0x54, 0x54, 0x3C,  // 103 'g'
    0x7F, 0x08, 0x04, 0x04, 0x78,  // 104 'h'
    0x00, 0x44, 0x7D, 0x40, 0x00,  // 105 'i'
    0x20, 0x40, 0x44, 0x3D, 0x00,  // 106 'j'
    0x00, 0x7F, 0x10, 0x28, 0x44,  // 107 'k'
    0x00, 0x41, 0x7F, 0x40, 0x00,  // 108 'l'
    0x7C, 0x04, 0x18, 0x04, 0x78,  // 109 'm'
    0x7C, 0x08, 0x04, 0x04, 0x78,  // 110 'n'
    0x38, 0x44, 0x44, 0x44, 0x38,  // 111 'o'
    0x7C, 0x14, 0x14, 0x14, 0x08,  // 112 'p'
    0x08, 0x14, 0x14, 0x18, 0x7C,  // 113 'q'
    0x7C, 0x08, 0x04, 0x04, 0x08,  // 114 'r'
    0x48, 0x54, 0x54, 0x54, 0x20,  // 115 's'
    0x04, 0x3F, 0x44, 0x40, 0x20,  // 116 't'
    0x3C, 0x40, 0x40, 0x20, 0x7C,  // 117 'u'
    0x1C, 0x20, 0x40, 0x20, 0x1C,  // 118 'v'
    0x3C, 0x40, 0x30, 0x40, 0x3C,  // 119 'w'
    0x44, 0x28, 0x10, 0x28, 0x44,  // 120 'x'
    0x0C, 0x50, 0x50, 0x50, 0x3C,  // 121 'y'
    0x44, 0x64, 0x54, 0x4C, 0x44,  // 122 'z'
    0x00, 0x08, 0x36, 0x41, 0x00,  // 123 '{'
    0x00, 0x00, 0x7F, 0x00, 0x00,  // 124 '|'
    0x00, 0x41, 0x36, 0x08, 0x00,  // 125 '}'
    0x08, 0x08, 0x2A, 0x1C, 0x08,  // 126 '~'
};

static constexpr uint8_t FONT_FIRST_CHAR = 32;
static constexpr uint8_t FONT_CHAR_COUNT = 95;  // 32-126
static constexpr uint8_t FONT_WIDTH = 5;
static constexpr uint8_t FONT_HEIGHT = 7;
static constexpr uint8_t CHAR_WIDTH = 6;   // Font width + 1px spacing
static constexpr uint8_t CHAR_HEIGHT = 8;  // Font height + 1px spacing

namespace {

static constexpr uint8_t OUT_LEFT = 0x01;
static constexpr uint8_t OUT_RIGHT = 0x02;
static constexpr uint8_t OUT_TOP = 0x04;
static constexpr uint8_t OUT_BOTTOM = 0x08;

bool isValidComPinsConfig(ComPinsConfig value) {
  switch (value) {
    case ComPinsConfig::SEQUENTIAL_NO_REMAP:
    case ComPinsConfig::ALTERNATIVE_NO_REMAP:
    case ComPinsConfig::SEQUENTIAL_REMAP:
    case ComPinsConfig::ALTERNATIVE_REMAP:
      return true;
  }
  return false;
}

bool isSupportedControllerProfile(ControllerProfile value) {
  switch (value) {
    case ControllerProfile::SSD1315:
      return true;
  }
  return false;
}

bool isValidChargePumpVoltage(ChargePumpVoltage value) {
  switch (value) {
    case ChargePumpVoltage::OFF:
    case ChargePumpVoltage::V7_5:
    case ChargePumpVoltage::V8_5:
    case ChargePumpVoltage::V9_0:
      return true;
  }
  return false;
}

bool isValidIrefSelection(IrefSelection value) {
  switch (value) {
    case IrefSelection::IREF_EXTERNAL:
    case IrefSelection::INTERNAL_19UA:
    case IrefSelection::INTERNAL_30UA:
      return true;
  }
  return false;
}

bool isValidVcomhLevel(VcomhLevel value) {
  switch (value) {
    case VcomhLevel::V_065_VCC:
    case VcomhLevel::V_071_VCC:
    case VcomhLevel::V_077_VCC:
    case VcomhLevel::V_083_VCC:
      return true;
  }
  return false;
}

bool isValidSsd1315Address(uint8_t address) {
  return address == 0x3C || address == 0x3D;
}

bool isAlternativeComPinsConfig(ComPinsConfig value) {
  return (static_cast<uint8_t>(value) & 0x10u) != 0;
}

bool isValidScrollSpeed(ScrollSpeed speed) {
  return static_cast<uint8_t>(speed) <=
         static_cast<uint8_t>(ScrollSpeed::FRAMES_2);
}

bool isValidFadeMode(FadeMode mode) {
  switch (mode) {
    case FadeMode::OFF:
    case FadeMode::FADE_OUT:
    case FadeMode::BLINK:
      return true;
  }
  return false;
}

bool isControlStateUncertainError(const Status& st) {
  switch (st.code) {
    case Err::I2C_NACK_ADDR:
    case Err::I2C_NACK_DATA:
    case Err::I2C_TIMEOUT:
    case Err::I2C_BUS_ERROR:
    case Err::TIMEOUT:
    case Err::DEVICE_NOT_FOUND:
    case Err::INTERNAL_ERROR:
      return true;
    default:
      return false;
  }
}

uint32_t saturatedAdd(uint32_t a, uint32_t b) {
  const uint32_t room = UINT32_MAX - a;
  return (b > room) ? UINT32_MAX : (a + b);
}

uint32_t saturatedMul(uint32_t value, uint32_t factor) {
  if (factor != 0 && value > UINT32_MAX / factor) {
    return UINT32_MAX;
  }
  return value * factor;
}

uint32_t waitFlushStallGuardIterations(uint32_t timeoutMs, uint32_t i2cTimeoutMs) {
  uint32_t budget = saturatedAdd(timeoutMs, i2cTimeoutMs);
  budget = saturatedMul(budget, 4u);
  budget = saturatedAdd(budget, 16u);
  return (budget < 32u) ? 32u : budget;
}

static constexpr size_t FLUSH_DATA_CHUNK_BYTES = 64;
static constexpr size_t COMMAND_LIST_MAX_BYTES = 32;
static constexpr size_t TEXT_MAX_CHARS = 512;

uint8_t outCode(int32_t x, int32_t y,
                int32_t xMin, int32_t yMin,
                int32_t xMax, int32_t yMax) {
  uint8_t code = 0;
  if (x < xMin) {
    code |= OUT_LEFT;
  } else if (x > xMax) {
    code |= OUT_RIGHT;
  }

  if (y < yMin) {
    code |= OUT_TOP;
  } else if (y > yMax) {
    code |= OUT_BOTTOM;
  }

  return code;
}

}  // namespace

// ============================================================================
// Constructor / Destructor
// ============================================================================

SSD1315::SSD1315() {
  memset(_dirtyMinCol, 0xFF, sizeof(_dirtyMinCol));
  memset(_dirtyMaxCol, 0x00, sizeof(_dirtyMaxCol));
}

SSD1315::~SSD1315() {
  end();
}

// ============================================================================
// Health tracking helpers
// ============================================================================

Status SSD1315::_updateHealth(const Status& st) {
  if (!_initialized || st.inProgress()) {
    return st;
  }

  bool isSuccess = st.ok();

  if (isSuccess) {
    _lastOkMs = _nowMs();
    _consecutiveFailures = 0;
    if (_totalSuccess < UINT32_MAX) {
      _totalSuccess++;
    }
  } else {
    _lastError = st;
    _lastErrorMs = _nowMs();
    // Saturate at 255 to prevent uint8_t wrap-around. Without saturation,
    // 256 consecutive failures would wrap the counter back to 0, causing the
    // READY→DEGRADED transition (which triggers at _consecutiveFailures == 1)
    // to fire again on the 257th failure instead of staying OFFLINE.
    // Successes still reset the counter to 0 normally — recovery is unaffected.
    if (_consecutiveFailures < 255u) {
      _consecutiveFailures++;
    }
    if (_totalFailures < UINT32_MAX) {
      _totalFailures++;
    }
  }

  // State transitions are only reached after initialization has been verified.
  if (_initialized) {
    if (isSuccess) {
      // Success returns the driver to READY when I2C is explicitly allowed.
      if (_driverState != DriverState::READY) {
        _driverState = DriverState::READY;
      }
    } else {
      // Failure handling: READY -> DEGRADED on first failure.
      if (_consecutiveFailures == 1 &&
          _driverState == DriverState::READY) {
        _driverState = DriverState::DEGRADED;
      }
      // DEGRADED -> OFFLINE when threshold reached.
      if (_consecutiveFailures >= _config.offlineThreshold) {
        _driverState = DriverState::OFFLINE;
      }
    }
  }
  return st;
}

Status SSD1315::getSettings(SettingsSnapshot& out) const {
  out.initialized = _initialized;
  out.state = _driverState;
  out.controllerProfile = _config.controllerProfile;
  out.i2cAddress = _config.i2cAddress;
  out.i2cTimeoutMs = _config.i2cTimeoutMs;
  out.offlineThreshold = _config.offlineThreshold;
  out.hasNowMsHook = (_config.nowMs != nullptr);
  out.hasCooperativeYieldHook = (_config.cooperativeYield != nullptr);
  out.hasI2cWriteReadHook = (_config.i2cWriteRead != nullptr);

  out.width = _config.width;
  out.height = _config.height;
  out.pageBufferPages = _config.pageBufferPages;
  out.totalPages = _totalPages;
  out.pageBufferMode = isPageBufferMode();
  out.sleeping = _sleeping;
  out.allPixelsOn = _allPixelsOn;
  out.userPageCount = _userPageCount;
  out.activeUserPage = _activeUserPage;
  out.currentPageIndex = _currentBufferPage;
  out.pageIterationActive = _inPageIteration;
  out.byteBudgetPerTick = _config.byteBudgetPerTick;
  out.flushTimeoutMs = _config.flushTimeoutMs;
  out.displayOnDelayMs = _config.displayOnDelayMs;
  out.inactivitySleepMs = _config.inactivitySleepMs;
  out.pageCycleMs = _config.pageCycleMs;
  out.flipX = _config.flipX;
  out.flipY = _config.flipY;
  out.invert = _config.invert;
  out.contrast = _config.contrast;
  out.comPins = static_cast<uint8_t>(_config.comPins);
  out.chargePumpVoltage = static_cast<uint8_t>(_config.chargePumpVoltage);
  out.iref = static_cast<uint8_t>(_config.iref);
  out.vcomh = static_cast<uint8_t>(_config.vcomh);
  out.clockDivide = _config.clockDivide;
  out.oscFrequency = _config.oscFrequency;
  out.prechargePhase1 = _config.prechargePhase1;
  out.prechargePhase2 = _config.prechargePhase2;
  out.scrollActive = _scrollActive;
  out.clearOnBegin = _config.clearOnBegin;
  out.clearOnRecover = _config.clearOnRecover;
  out.hasExternalBuffer = (_config.externalBuffer != nullptr);
  out.ownsBuffer = _ownsBuffer;
  out.bufferSize = getBufferSize();
  out.dirtyPages = _dirtyPages;
  out.flushing = isFlushing();
  out.controlStateDirty = _controlStateDirty;
  out.controlStateError = _controlStateError;
  out.lastOkMs = _lastOkMs;
  out.lastErrorMs = _lastErrorMs;
  out.consecutiveFailures = _consecutiveFailures;
  out.totalFailures = _totalFailures;
  out.totalSuccess = _totalSuccess;
  out.lastError = _lastError;
  return Ok();
}

uint32_t SSD1315::_nowMs() const {
  if (_config.nowMs != nullptr) {
    return _config.nowMs(_config.timeUser);
  }
  return 0U;
}

void SSD1315::_cooperativeYield() const {
  if (_config.cooperativeYield != nullptr) {
    _config.cooperativeYield(_config.timeUser);
  }
}

Status SSD1315::_i2cWriteRaw(const uint8_t* data, size_t len) {
  if (!_config.i2cWrite) {
    return Error(Err::INVALID_CONFIG, "I2C write callback null");
  }
  if (data == nullptr || len == 0) {
    return Error(Err::INVALID_CONFIG, "I2C write buffer invalid");
  }
  return _config.i2cWrite(_config.i2cAddress, data, len,
                          _config.i2cTimeoutMs, _config.i2cUser);
}

Status SSD1315::_i2cWriteTracked(const uint8_t* data, size_t len) {
  if (!_config.i2cWrite) {
    return Error(Err::INVALID_CONFIG, "I2C write callback null");
  }
  if (data == nullptr || len == 0) {
    return Error(Err::INVALID_CONFIG, "I2C write buffer invalid");
  }
  if (!_allowOfflineI2c && _initialized && _driverState == DriverState::OFFLINE) {
    return _offlineStatus();
  }
  Status st = _i2cWriteRaw(data, len);
  return _updateHealth(st);
}

Status SSD1315::_offlineStatus() const {
  return Error(Err::BUSY, "Driver is offline; call recover()");
}

void SSD1315::_reassertOfflineLatch() {
  _driverState = DriverState::OFFLINE;
  const uint8_t threshold = _config.offlineThreshold == 0 ? 1 : _config.offlineThreshold;
  if (_consecutiveFailures < threshold) {
    _consecutiveFailures = threshold;
  }
}

void SSD1315::_resetRuntimeState() {
  if (_ownsBuffer && _buffer != nullptr) {
    delete[] _buffer;
  }

  _config = Config{};
  _initialized = false;
  _sleeping = true;
  _allPixelsOn = false;
  _scrollActive = false;

  _buffer = nullptr;
  _ownsBuffer = false;
  _totalPages = 0;

  _dirtyPages = 0;
  memset(_dirtyMinCol, 0xFF, sizeof(_dirtyMinCol));
  memset(_dirtyMaxCol, 0x00, sizeof(_dirtyMaxCol));
  memset(_dirtyGeneration, 0x00, sizeof(_dirtyGeneration));

  _flushState = FlushState::IDLE;
  _flushPage = 0;
  _flushCol = 0;
  _flushEndPage = 0;
  _flushMinCol = 0;
  _flushMaxCol = 0;
  _flushPageGeneration = 0;
  _flushStartMs = 0;
  _flushStarted = false;
  _flushAccounted = false;
  _lastError = Ok();

  _powerState = PowerState::OFF;
  _powerOnMs = 0;
  _powerOnDelayStarted = false;
  _verticalScrollTopRows = 0;
  _verticalScrollRows = MAX_HEIGHT;

  _lastActivityMs = 0;
  _lastWakeAttemptMs = 0;
  _autoSleepMs = 0;

  _userPageCount = 1;
  _activeUserPage = 0;
  _pageCycleMs = 0;
  _lastPageCycleMs = 0;

  _currentBufferPage = 0;
  _inPageIteration = false;

  _driverState = DriverState::UNINIT;
  _lastOkMs = 0;
  _lastErrorMs = 0;
  _consecutiveFailures = 0;
  _totalFailures = 0;
  _totalSuccess = 0;
  _allowOfflineI2c = false;
  _flushError = Ok();
}

void SSD1315::_markControlStateDirty(const Status& st) {
  if (st.ok() || st.inProgress() || !isControlStateUncertainError(st)) {
    return;
  }
  _controlStateDirty = true;
  _controlStateError = st;
}

void SSD1315::_clearControlStateDirty() {
  _controlStateDirty = false;
  _controlStateError = Ok();
}

Status SSD1315::_applyConfig(bool clearDisplayRam) {
  // Apply stored configuration to device.
  // Used by both begin() and recover().
  // Uses tracked I2C wrappers for health tracking.

  Status st;

  // Step 1: Run init sequence (uses sendCommand* which will be tracked)
  st = initDisplay();
  if (!st.ok()) {
    _markControlStateDirty(st);
    return st;
  }

  // Step 2: Clear GDDRAM unless the application chose a shorter lifecycle.
  if (clearDisplayRam) {
    st = clearGddram();
    if (!st.ok()) {
      markAllDirty();
      _markControlStateDirty(st);
      return st;
    }
  } else {
    markAllDirty();
  }

  // Step 3: Turn display on only after init and optional clear complete.
  st = _turnDisplayOnAfterInit();
  if (!st.ok()) {
    _markControlStateDirty(st);
    return st;
  }

  _clearControlStateDirty();
  return Ok();
}

// ============================================================================
// Probe and recovery
// ============================================================================

Status SSD1315::_probeRaw() {
  // SSD1315 has no WHOAMI register. We send NOP (0xE3) and check ACK.
  // NOP command is safe and has no side effects.
  if (!_config.i2cWrite) {
    return Error(Err::INVALID_CONFIG, "I2C write callback null");
  }

  uint8_t buf[2] = {cmd::CTRL_COMMAND, cmd::NOP};
  Status st = _i2cWriteRaw(buf, 2);  // No health tracking!

  if (st.code == Err::I2C_NACK_ADDR) {
    return Error(Err::DEVICE_NOT_FOUND, st.detail, "Device not responding");
  }

  // Note: probe() does NOT call _updateHealth() - diagnostic only
  return st;
}

Status SSD1315::probe() {
  if (!_initialized) {
    return Error(Err::NOT_INITIALIZED, "not initialized");
  }
  return _probeRaw();
}

Status SSD1315::recover() {
  // Can't recover if never initialized
  if (!_initialized) {
    return Error(Err::NOT_INITIALIZED, "begin() not called");
  }

  const bool startedOffline = (_driverState == DriverState::OFFLINE);

  // Step 1: Probe device (probe itself is diagnostic-only)
  Status st = _probeRaw();
  if (!st.ok()) {
    // Explicitly track probe failure as a real failure
    _updateHealth(st);
    if (startedOffline && !st.inProgress()) {
      _reassertOfflineLatch();
    }
    return st;
  }

  // Step 2: Re-apply configuration (includes init sequence)
  // _applyConfig uses tracked wrappers internally via sendCommand*
  ScopedOfflineI2cAllowance allowOfflineI2c(_allowOfflineI2c, true);
  st = _applyConfig(_config.clearOnRecover);
  // Note: _updateHealth already called by sendCommand* internals
  if (startedOffline && !st.ok() && !st.inProgress()) {
    _reassertOfflineLatch();
  }
  if (!st.ok()) {
    _markControlStateDirty(st);
  }

  if (st.ok()) {
    // Step 3: Mark framebuffer dirty for resync
    markAllDirty();
  }

  return st;
}

// ============================================================================
// Lifecycle
// ============================================================================

Status SSD1315::begin(const Config& config) {
  _resetRuntimeState();

  // ========== Validate configuration BEFORE copying ==========
  // All validation uses the input 'config' parameter, not _config.
  // This ensures _config is only set after validation passes.

  if (config.i2cWrite == nullptr) {
    return Error(Err::INVALID_CONFIG, "i2cWrite callback is null");
  }
  if (!isSupportedControllerProfile(config.controllerProfile)) {
    return Error(Err::INVALID_CONFIG, "unsupported controller profile");
  }
  if (config.width == 0 || config.width > MAX_WIDTH) {
    return Error(Err::INVALID_DIMENSIONS, "width out of range [1..128]");
  }
  if (config.height < 16 || config.height > MAX_HEIGHT || (config.height % 8) != 0) {
    return Error(Err::INVALID_DIMENSIONS, "height must be 16..64, multiple of 8");
  }
  if (!isValidSsd1315Address(config.i2cAddress)) {
    return Error(Err::INVALID_CONFIG, "i2cAddress must be SSD1315 7-bit 0x3C or 0x3D");
  }
  if (config.clockDivide == 0 || config.clockDivide > 16) {
    return Error(Err::INVALID_CONFIG, "clockDivide must be 1..16");
  }
  if (config.oscFrequency > 15) {
    return Error(Err::INVALID_CONFIG, "oscFrequency must be 0..15");
  }
  if (config.prechargePhase1 == 0 || config.prechargePhase1 > 15 ||
      config.prechargePhase2 == 0 || config.prechargePhase2 > 15) {
    return Error(Err::INVALID_CONFIG, "prechargePhase1/2 must be 1..15");
  }
  if (config.contrast < cmd::CONTRAST_MIN) {
    return Error(Err::INVALID_CONFIG, "contrast must be 1..255");
  }
  if (config.displayOffset > 63) {
    return Error(Err::INVALID_CONFIG, "displayOffset must be 0..63");
  }
  if (config.startLine > 63) {
    return Error(Err::INVALID_CONFIG, "startLine must be 0..63");
  }
  if (config.i2cTimeoutMs == 0) {
    return Error(Err::INVALID_CONFIG, "i2cTimeoutMs must be > 0");
  }
  if (config.byteBudgetPerTick == 0) {
    return Error(Err::INVALID_CONFIG, "byteBudgetPerTick must be > 0");
  }
  if (!isValidComPinsConfig(config.comPins)) {
    return Error(Err::INVALID_CONFIG, "invalid comPins enum");
  }
  if (!isValidChargePumpVoltage(config.chargePumpVoltage)) {
    return Error(Err::INVALID_CONFIG, "invalid chargePumpVoltage enum");
  }
  if (!isValidIrefSelection(config.iref)) {
    return Error(Err::INVALID_CONFIG, "invalid iref enum");
  }
  if (!isValidVcomhLevel(config.vcomh)) {
    return Error(Err::INVALID_CONFIG, "invalid vcomh enum");
  }

  const uint8_t totalPages = config.height / 8;
  if (config.pageBufferPages == 0 || config.pageBufferPages > totalPages) {
    return Error(Err::INVALID_PAGE_COUNT, "pageBufferPages out of range");
  }

  // ========== Validation passed — now copy config and initialize state ==========

  _config = config;
  _totalPages = totalPages;
  _driverState = DriverState::UNINIT;
  _initialized = false;

  // Clamp threshold (modify our copy, not the input)
  if (_config.offlineThreshold < 1) {
    _config.offlineThreshold = 1;
  }

  // Reset health tracking
  _lastOkMs = 0;
  _lastErrorMs = 0;
  _lastError = Ok();
  _consecutiveFailures = 0;
  _totalFailures = 0;
  _totalSuccess = 0;
  _flushError = Ok();

  // Probe device (uses _config.i2cWrite which is now set)
  Status st = _probeRaw();
  if (!st.ok()) {
    _resetRuntimeState();
    return st;
  }

  // Allocate or assign buffer
  size_t bufSize = static_cast<size_t>(_config.width) * _config.pageBufferPages;
  if (_config.externalBuffer != nullptr) {
    _buffer = _config.externalBuffer;
    _ownsBuffer = false;
  } else {
    _buffer = new (std::nothrow) uint8_t[bufSize];
    if (_buffer == nullptr) {
      _resetRuntimeState();
      return Error(Err::INTERNAL_ERROR, "buffer allocation failed");
    }
    _ownsBuffer = true;
  }

  // Clear buffer
  memset(_buffer, 0, bufSize);

  // Reset state
  _sleeping = true;
  _allPixelsOn = false;
  _flushState = FlushState::IDLE;
  _dirtyPages = 0;
  memset(_dirtyMinCol, 0xFF, sizeof(_dirtyMinCol));
  memset(_dirtyMaxCol, 0x00, sizeof(_dirtyMaxCol));
  memset(_dirtyGeneration, 0x00, sizeof(_dirtyGeneration));
  _currentBufferPage = 0;
  _inPageIteration = false;
  _lastWakeAttemptMs = 0;

  // Copy feature config
  _autoSleepMs = _config.inactivitySleepMs;
  _pageCycleMs = _config.pageCycleMs;
  _userPageCount = 1;
  _activeUserPage = 0;

  // Keep _initialized false during config application so begin-time I2C does
  // not update health counters.
  _initialized = false;
  // Note: begin() sets READY only after _applyConfig() succeeds.

  // Apply config (includes init sequence)
  // _applyConfig uses tracked wrappers, but health updates are ignored until
  // begin() succeeds.
  st = _applyConfig(_config.clearOnBegin);
  if (!st.ok()) {
    _resetRuntimeState();
    return st;
  }

  _initialized = true;
  _driverState = DriverState::READY;
  return Ok();
}

void SSD1315::tick(uint32_t nowMs) {
  if (!_initialized) {
    return;
  }
  if (_driverState == DriverState::OFFLINE) {
    return;
  }

  // Handle power-on timing
  tickPowerOn(nowMs);

  // Drive flush state machine
  tickFlush(nowMs);

  // Handle auto-sleep
  tickAutoSleep(nowMs);

  // Handle page cycling
  tickPageCycle(nowMs);
}

void SSD1315::end() {
  if (!_initialized) {
    return;
  }

  // Best-effort display off and charge-pump shutdown. Use raw writes so the
  // OFFLINE latch alone does not prevent a final physical shutdown attempt.
  // end() remains destructor-safe: it does not update health, allocate, throw,
  // or report failure through the void API.
  const uint8_t displayOff[] = {cmd::CTRL_COMMAND, cmd::DISPLAY_OFF};
  Status shutdownStatus = _i2cWriteRaw(displayOff, sizeof(displayOff));
  if (!shutdownStatus.ok()) {
    _lastError = shutdownStatus;
    _markControlStateDirty(shutdownStatus);
  }
  if (_config.chargePumpVoltage != ChargePumpVoltage::OFF) {
    const uint8_t chargePumpOff[] = {
        cmd::CTRL_COMMAND, cmd::SET_CHARGE_PUMP,
        static_cast<uint8_t>(ChargePumpVoltage::OFF)};
    Status pumpStatus = _i2cWriteRaw(chargePumpOff, sizeof(chargePumpOff));
    if (!pumpStatus.ok() && shutdownStatus.ok()) {
      _lastError = pumpStatus;
      _markControlStateDirty(pumpStatus);
    }
  }

  // Free buffer if we own it
  if (_ownsBuffer && _buffer != nullptr) {
    delete[] _buffer;
  }
  _buffer = nullptr;
  _ownsBuffer = false;
  _initialized = false;
  _sleeping = true;
  _allPixelsOn = false;
  _scrollActive = false;
  _driverState = DriverState::UNINIT;
  _powerState = PowerState::OFF;
  _lastWakeAttemptMs = 0;
  _powerOnDelayStarted = false;
  _flushState = FlushState::IDLE;
  _flushStarted = false;
  _flushAccounted = false;
  _flushError = Ok();
  _dirtyPages = 0;
  memset(_dirtyMinCol, 0xFF, sizeof(_dirtyMinCol));
  memset(_dirtyMaxCol, 0x00, sizeof(_dirtyMaxCol));
  _currentBufferPage = 0;
  _inPageIteration = false;

  // Note: Health counters and timestamps are NOT reset.
  // They remain available for post-mortem diagnostics.
  // Counters will be reset on next begin() call.
}

// ============================================================================
// Display initialization
// ============================================================================

Status SSD1315::initDisplay() {
  // Initialization sequence based on SSD1315 datasheet recommendations
  // Keep display off during setup
  Status st;

  st = _sendCommand(cmd::DISPLAY_OFF);
  if (!st.ok()) return st;

  // Set memory addressing mode to horizontal
  st = _sendCommand2(cmd::SET_MEMORY_MODE, cmd::ADDR_MODE_HORIZONTAL);
  if (!st.ok()) return st;

  // Set display start line to 0
  st = _sendCommand(cmd::SET_START_LINE | (_config.startLine & 0x3F));
  if (!st.ok()) return st;

  // Set segment remap (flip X)
  st = _sendCommand(_config.flipX ? cmd::SEG_REMAP_ON : cmd::SEG_REMAP_OFF);
  if (!st.ok()) return st;

  // Set multiplex ratio (height - 1)
  st = _sendCommand2(cmd::SET_MULTIPLEX, _config.height - 1);
  if (!st.ok()) return st;

  // Set COM scan direction (flip Y)
  st = _sendCommand(_config.flipY ? cmd::COM_SCAN_DEC : cmd::COM_SCAN_INC);
  if (!st.ok()) return st;

  // Set display offset
  st = _sendCommand2(cmd::SET_DISPLAY_OFFSET, _config.displayOffset);
  if (!st.ok()) return st;

  // Set COM pins configuration
  st = _sendCommand2(cmd::SET_COM_PINS, static_cast<uint8_t>(_config.comPins));
  if (!st.ok()) return st;

  // Set clock divide ratio and oscillator frequency
  uint8_t clockDiv = ((_config.oscFrequency & 0x0F) << 4) | ((_config.clockDivide - 1) & 0x0F);
  st = _sendCommand2(cmd::SET_CLOCK_DIV, clockDiv);
  if (!st.ok()) return st;

  // Set pre-charge period
  uint8_t precharge = ((_config.prechargePhase2 & 0x0F) << 4) | (_config.prechargePhase1 & 0x0F);
  st = _sendCommand2(cmd::SET_PRECHARGE, precharge);
  if (!st.ok()) return st;

  // Set VCOMH level
  st = _sendCommand2(cmd::SET_VCOMH, static_cast<uint8_t>(_config.vcomh));
  if (!st.ok()) return st;

  // Set contrast
  st = _sendCommand2(cmd::SET_CONTRAST, _config.contrast);
  if (!st.ok()) return st;

  // SSD1315-specific: Set IREF selection
  st = _sendCommand2(cmd::SET_IREF, static_cast<uint8_t>(_config.iref));
  if (!st.ok()) return st;

  // Enable charge pump
  st = _sendCommand2(cmd::SET_CHARGE_PUMP, static_cast<uint8_t>(_config.chargePumpVoltage));
  if (!st.ok()) return st;

  // Resume to RAM content (not all-on)
  st = _sendCommand(cmd::DISPLAY_RAM);
  if (!st.ok()) return st;

  // Set normal/inverse display
  st = _sendCommand(_config.invert ? cmd::INVERT_DISPLAY : cmd::NORMAL_DISPLAY);
  if (!st.ok()) return st;

  // Deactivate scroll
  st = _sendCommand(cmd::SCROLL_DEACTIVATE);
  if (!st.ok()) return st;
  _scrollActive = false;
  _verticalScrollTopRows = 0;
  _verticalScrollRows = _config.height;

  return Ok();
}

Status SSD1315::_turnDisplayOnAfterInit() {
  Status st = _sendCommand(cmd::DISPLAY_ON);
  if (!st.ok()) return st;

  // Start power-on timing guard.
  if (_config.displayOnDelayMs == 0) {
    _powerState = PowerState::READY;
    _powerOnDelayStarted = false;
  } else {
    _powerState = PowerState::INIT_DELAY;
    _powerOnMs = 0;
    _powerOnDelayStarted = false;  // Will be set on first tick
  }
  _sleeping = false;

  return Ok();
}

Status SSD1315::clearGddram() {
  // Clear all GDDRAM by writing zeros to entire display RAM.
  // This is a BLOCKING operation used during initialization.
  // For 128x64: 8 pages × 128 columns = 1024 bytes.

  Status st;

  // Set addressing window to full screen (horizontal addressing mode)
  st = _sendCommand3(cmd::SET_COL_ADDR, 0, _config.width - 1);
  if (!st.ok()) return st;
  st = _sendCommand3(cmd::SET_PAGE_ADDR, 0, _totalPages - 1);
  if (!st.ok()) return st;

  // Send zeros in chunks (ESP32 Wire buffer is 128 bytes max)
  // Use stack buffer to avoid heap allocation
  constexpr size_t CHUNK_SIZE = 32;  // Small chunks for reliability
  uint8_t buf[CHUNK_SIZE + 1];
  buf[0] = cmd::CTRL_DATA;
  memset(buf + 1, 0x00, CHUNK_SIZE);

  size_t totalBytes = static_cast<size_t>(_config.width) * _totalPages;
  size_t sent = 0;

  while (sent < totalBytes) {
    size_t chunk = (totalBytes - sent) > CHUNK_SIZE ? CHUNK_SIZE : (totalBytes - sent);
    // Use tracked write for clearGddram during init
    st = _i2cWriteTracked(buf, chunk + 1);
    if (!st.ok()) return st;
    sent += chunk;
  }

  return Ok();
}

// ============================================================================
// Raw command access
// ============================================================================

Status SSD1315::_sendCommand(uint8_t command) {
  uint8_t buf[2] = {cmd::CTRL_COMMAND, command};
  return _i2cWriteTracked(buf, 2);
}

Status SSD1315::_sendCommand2(uint8_t command, uint8_t arg) {
  uint8_t buf[3] = {cmd::CTRL_COMMAND, command, arg};
  return _i2cWriteTracked(buf, 3);
}

Status SSD1315::_sendCommand3(uint8_t command, uint8_t arg1, uint8_t arg2) {
  uint8_t buf[4] = {cmd::CTRL_COMMAND, command, arg1, arg2};
  return _i2cWriteTracked(buf, 4);
}

Status SSD1315::sendCommand(uint8_t cmd) {
  if (!_initialized) return Error(Err::NOT_INITIALIZED, "not initialized");
  Status st = _sendCommand(cmd);
  if (!st.ok()) {
    _markControlStateDirty(st);
  }
  return st;
}

Status SSD1315::sendCommand2(uint8_t cmd, uint8_t arg) {
  if (!_initialized) return Error(Err::NOT_INITIALIZED, "not initialized");
  Status st = _sendCommand2(cmd, arg);
  if (!st.ok()) {
    _markControlStateDirty(st);
  }
  return st;
}

Status SSD1315::sendCommand3(uint8_t cmd, uint8_t arg1, uint8_t arg2) {
  if (!_initialized) return Error(Err::NOT_INITIALIZED, "not initialized");
  Status st = _sendCommand3(cmd, arg1, arg2);
  if (!st.ok()) {
    _markControlStateDirty(st);
  }
  return st;
}

Status SSD1315::sendCommandList(const uint8_t* cmds, size_t len) {
  if (!_initialized) return Error(Err::NOT_INITIALIZED, "not initialized");
  if (len == 0) return Ok();
  if (cmds == nullptr) {
    return Error(Err::INVALID_CONFIG, "command list buffer invalid");
  }
  if (len > COMMAND_LIST_MAX_BYTES) {
    return Error(Err::BUFFER_OVERFLOW, "command list too long");
  }

  // Send commands with control byte prefix
  // We need a buffer for control byte + commands
  // Use small stack buffer and send in chunks if needed
  constexpr size_t CHUNK_SIZE = 32;
  uint8_t buf[CHUNK_SIZE + 1];
  buf[0] = cmd::CTRL_COMMAND;

  size_t sent = 0;
  while (sent < len) {
    size_t chunk = (len - sent) > CHUNK_SIZE ? CHUNK_SIZE : (len - sent);
    memcpy(buf + 1, cmds + sent, chunk);
    Status st = _i2cWriteTracked(buf, chunk + 1);
    if (!st.ok()) {
      _markControlStateDirty(st);
      return st;
    }
    sent += chunk;
  }
  return Ok();
}

// ============================================================================
// Display control
// ============================================================================

Status SSD1315::setContrast(uint8_t contrast) {
  if (!_initialized) return Error(Err::NOT_INITIALIZED, "not initialized");
  if (contrast < cmd::CONTRAST_MIN) {
    return Error(Err::INVALID_CONFIG, "contrast must be 1..255");
  }
  Status st = sendCommand2(cmd::SET_CONTRAST, contrast);
  if (st.ok()) {
    _config.contrast = contrast;
  } else {
    _markControlStateDirty(st);
  }
  return st;
}

Status SSD1315::setInvert(bool invert) {
  if (!_initialized) return Error(Err::NOT_INITIALIZED, "not initialized");
  Status st = sendCommand(invert ? cmd::INVERT_DISPLAY : cmd::NORMAL_DISPLAY);
  if (st.ok()) {
    _config.invert = invert;
  } else {
    _markControlStateDirty(st);
  }
  return st;
}

Status SSD1315::setFlipX(bool flip) {
  if (!_initialized) return Error(Err::NOT_INITIALIZED, "not initialized");
  Status st = sendCommand(flip ? cmd::SEG_REMAP_ON : cmd::SEG_REMAP_OFF);
  if (st.ok()) {
    _config.flipX = flip;
  } else {
    _markControlStateDirty(st);
  }
  return st;
}

Status SSD1315::setFlipY(bool flip) {
  if (!_initialized) return Error(Err::NOT_INITIALIZED, "not initialized");
  Status st = sendCommand(flip ? cmd::COM_SCAN_DEC : cmd::COM_SCAN_INC);
  if (st.ok()) {
    _config.flipY = flip;
  } else {
    _markControlStateDirty(st);
  }
  return st;
}

Status SSD1315::setSleep(bool sleep) {
  if (!_initialized) return Error(Err::NOT_INITIALIZED, "not initialized");

  Status st = sendCommand(sleep ? cmd::DISPLAY_OFF : cmd::DISPLAY_ON);
  if (st.ok()) {
    _sleeping = sleep;
    _lastWakeAttemptMs = 0;
    if (!sleep) {
      // Waking up - start power-on timing guard
      if (_config.displayOnDelayMs == 0) {
        _powerState = PowerState::READY;
        _powerOnDelayStarted = false;
      } else {
        _powerState = PowerState::INIT_DELAY;
        _powerOnMs = 0;
        _powerOnDelayStarted = false;  // Will be set on next tick
      }
    }
  } else {
    _markControlStateDirty(st);
  }
  return st;
}

Status SSD1315::setAllPixelsOn(bool allOn) {
  if (!_initialized) return Error(Err::NOT_INITIALIZED, "not initialized");
  Status st = sendCommand(allOn ? cmd::DISPLAY_ALL_ON : cmd::DISPLAY_RAM);
  if (st.ok()) {
    _allPixelsOn = allOn;
  } else {
    _markControlStateDirty(st);
  }
  return st;
}

// ============================================================================
// Auto-sleep and activity
// ============================================================================

void SSD1315::setAutoSleep(uint32_t inactivityMs) {
  _autoSleepMs = inactivityMs;
  _config.inactivitySleepMs = inactivityMs;
}

void SSD1315::touch() {
  if (!_initialized) return;
  // Delegate to resetActivityTimer() to ensure the "not-started" sentinel (0)
  // is never written to _lastActivityMs, even when the injected clock is 0.
  resetActivityTimer(_nowMs());
  wakeIfSleeping();
}

void SSD1315::resetActivityTimer(uint32_t nowMs) {
  // 0 is used as the "not-started" sentinel in tickAutoSleep; avoid writing it.
  // If nowMs is genuinely 0 (boot edge case), use 1 to keep the sentinel distinct.
  _lastActivityMs = (nowMs != 0) ? nowMs : 1u;
}

void SSD1315::wakeIfSleeping() {
  if (_sleeping && _initialized) {
    const uint32_t nowMs = _nowMs();
    constexpr uint32_t WAKE_RETRY_BACKOFF_MS = 10;

    if (_lastWakeAttemptMs != 0 &&
        (nowMs - _lastWakeAttemptMs) < WAKE_RETRY_BACKOFF_MS) {
      return;
    }

    _lastWakeAttemptMs = nowMs;
    Status st = setSleep(false);
    if (st.ok()) {
      _lastWakeAttemptMs = 0;
    }
  }
}

// ============================================================================
// Page cycling
// ============================================================================

void SSD1315::setUserPageCount(uint8_t count) {
  _userPageCount = (count == 0) ? 1 : count;
  if (_activeUserPage >= _userPageCount) {
    _activeUserPage = 0;
  }
}

void SSD1315::setActiveUserPage(uint8_t index) {
  _activeUserPage = (index < _userPageCount) ? index : 0;
}

void SSD1315::setPageCycleInterval(uint32_t intervalMs) {
  _pageCycleMs = intervalMs;
  _config.pageCycleMs = intervalMs;
  _lastPageCycleMs = 0;  // Reset timer
}

// ============================================================================
// Tick helpers
// ============================================================================

void SSD1315::tickPowerOn(uint32_t nowMs) {
  if (_powerState == PowerState::INIT_DELAY) {
    if (_config.displayOnDelayMs == 0) {
      _powerState = PowerState::READY;
      _powerOnDelayStarted = false;
      return;
    }
    if (!_powerOnDelayStarted) {
      _powerOnMs = nowMs;
      _powerOnDelayStarted = true;
      return;
    }
    // Unsigned subtraction handles 32-bit clock rollover correctly.
    uint32_t elapsed = nowMs - _powerOnMs;
    if (elapsed >= _config.displayOnDelayMs) {
      _powerState = PowerState::READY;
      _powerOnDelayStarted = false;
    }
  }
}

void SSD1315::tickAutoSleep(uint32_t nowMs) {
  if (_autoSleepMs == 0 || _sleeping) return;

  if (_lastActivityMs == 0) {
    // First observation: record current time to start the inactivity window.
    // Avoid writing 0 (the sentinel): if the injected clock is 0, use 1.
    _lastActivityMs = (nowMs != 0) ? nowMs : 1u;
    return;
  }

  uint32_t inactive = nowMs - _lastActivityMs;
  if (inactive >= _autoSleepMs) {
    setSleep(true);
  }
}

void SSD1315::tickPageCycle(uint32_t nowMs) {
  if (_pageCycleMs == 0 || _userPageCount <= 1) return;

  if (_lastPageCycleMs == 0) {
    // Avoid writing 0 (the sentinel): if millis() is genuinely 0, use 1.
    _lastPageCycleMs = (nowMs != 0) ? nowMs : 1u;
    return;
  }

  uint32_t elapsed = nowMs - _lastPageCycleMs;
  if (elapsed >= _pageCycleMs) {
    _lastPageCycleMs = nowMs;
    _activeUserPage = (_activeUserPage + 1) % _userPageCount;
  }
}

void SSD1315::tickFlush(uint32_t nowMs) {
  (void)pollFlush(nowMs, 1, _config.byteBudgetPerTick);
}

Status SSD1315::pollFlush(uint32_t nowMs, uint8_t maxInstructions, uint16_t byteBudget) {
  if (!_initialized) {
    return Error(Err::NOT_INITIALIZED, "not initialized");
  }
  if (_driverState == DriverState::OFFLINE) {
    return _offlineStatus();
  }

  tickPowerOn(nowMs);

  if (_inPageIteration &&
      (_flushState == FlushState::DONE || _flushState == FlushState::ERROR)) {
    return (_flushState == FlushState::ERROR)
               ? (_flushError.ok() ? Error(Err::INTERNAL_ERROR, "flush failed") : _flushError)
               : Ok();
  }

  // Handle completed flush states - track health once at completion
  if (_flushState == FlushState::DONE) {
    // Flush completed successfully - track once. A direct pollFlush() caller
    // may already have observed the terminal OK on the completing call.
    if (!_flushAccounted) {
      _updateHealth(Ok());
    }
    _flushAccounted = false;
    _flushState = FlushState::IDLE;
    return Ok();
  }

  if (_flushState == FlushState::ERROR) {
    // Flush failed - track once with accumulated error. A direct pollFlush()
    // caller may already have observed the terminal error on the failing call.
    Status flushFailure =
        _flushError.ok() ? Error(Err::INTERNAL_ERROR, "flush failed") : _flushError;
    if (!_flushAccounted) {
      _updateHealth(flushFailure);
    }
    _flushError = flushFailure;
    _flushAccounted = false;
    _flushState = FlushState::IDLE;
    return flushFailure;
  }

  if (_flushState == FlushState::IDLE) {
    return Ok();
  }

  if (byteBudget == 0) {
    return Error(Err::INVALID_CONFIG, "byteBudget must be > 0");
  }

  // Initialize flush start time if a job was created by older state or tests.
  // A boolean flag avoids sentinel ambiguity when the injected clock is 0 or
  // rolls over to UINT32_MAX.
  if (!_flushStarted) {
    _flushStarted = true;
    _flushStartMs = nowMs;
    _flushError = Ok();  // Reset accumulated error
    _flushAccounted = false;
  }

  // Check timeout
  if (_config.flushTimeoutMs > 0) {
    uint32_t elapsed = nowMs - _flushStartMs;
    if (elapsed > _config.flushTimeoutMs) {
      _flushError = Error(Err::TIMEOUT, "flush timeout");
      // Write _lastError immediately for real-time diagnostics.
      _lastError = _flushError;
      _flushState = FlushState::ERROR;
      if (!_inPageIteration) {
        _updateHealth(_flushError);
        _flushAccounted = true;
      }
      return _flushError;
    }
  }

  // Don't flush if panel not ready, but do include this wait in the flush
  // timeout budget checked above.
  if (_powerState != PowerState::READY) {
    return Error(Err::IN_PROGRESS, "flush waiting for panel");
  }

  Status st;

  uint8_t instructionsLeft = maxInstructions;
  uint16_t dataBudget = byteBudget;

  while (instructionsLeft > 0) {
    switch (_flushState) {
      case FlushState::SET_COL_ADDR: {
        uint8_t colBuf[4] = {cmd::CTRL_COMMAND, cmd::SET_COL_ADDR,
                             _flushMinCol,
                             _flushMaxCol};
        st = _i2cWriteRaw(colBuf, sizeof(colBuf));
        if (!st.ok()) {
          _flushError = st;
          _lastError = st;  // Immediate diagnostics.
          _flushState = FlushState::ERROR;
          if (!_inPageIteration) {
            _updateHealth(st);
            _flushAccounted = true;
          }
          return st;
        }
        instructionsLeft--;
        _flushState = FlushState::SET_PAGE_ADDR;
        break;
      }

      case FlushState::SET_PAGE_ADDR: {
        uint8_t pageBuf[4] = {cmd::CTRL_COMMAND, cmd::SET_PAGE_ADDR,
                              _flushPage, _flushPage};
        st = _i2cWriteRaw(pageBuf, sizeof(pageBuf));
        if (!st.ok()) {
          _flushError = st;
          _lastError = st;  // Immediate diagnostics.
          _flushState = FlushState::ERROR;
          if (!_inPageIteration) {
            _updateHealth(st);
            _flushAccounted = true;
          }
          return st;
        }
        instructionsLeft--;
        _flushCol = _flushMinCol;
        _flushState = FlushState::SEND_DATA;
        break;
      }

      case FlushState::SEND_DATA: {
        if (dataBudget == 0) {
          return Error(Err::IN_PROGRESS, "flush data budget exhausted");
        }

        const uint8_t bufferPage = _flushPage % _config.pageBufferPages;
        const size_t remaining = _flushMaxCol - _flushCol + 1;
        size_t toSend = remaining;
        if (toSend > FLUSH_DATA_CHUNK_BYTES) {
          toSend = FLUSH_DATA_CHUNK_BYTES;
        }
        if (toSend > dataBudget) {
          toSend = dataBudget;
        }

        const size_t bufOffset = _flushCol + static_cast<size_t>(bufferPage) * _config.width;
        uint8_t txBuf[FLUSH_DATA_CHUNK_BYTES + 1];
        txBuf[0] = cmd::CTRL_DATA;
        memcpy(txBuf + 1, _buffer + bufOffset, toSend);

        st = _i2cWriteRaw(txBuf, toSend + 1);
        if (!st.ok()) {
          _flushError = st;  // Accumulate error.
          _lastError = st;   // Immediate diagnostics.
          _flushState = FlushState::ERROR;
          if (!_inPageIteration) {
            _updateHealth(st);
            _flushAccounted = true;
          }
          return st;
        }

        instructionsLeft--;
        dataBudget -= static_cast<uint16_t>(toSend);
        _flushCol += static_cast<uint16_t>(toSend);

        if (_flushCol <= _flushMaxCol) {
          break;
        }

        // Clear the page only if no framebuffer mutator marked it dirty while
        // this page was being transferred. Otherwise leave it dirty so a later
        // requestFlush() retries the current framebuffer.
        if (_dirtyGeneration[_flushPage] == _flushPageGeneration) {
          _dirtyPages &= static_cast<uint8_t>(~(1u << _flushPage));
          _dirtyMinCol[_flushPage] = 0xFF;
          _dirtyMaxCol[_flushPage] = 0x00;
        }

        _flushPage++;
        bool found = false;
        while (_flushPage <= _flushEndPage) {
          if (_dirtyPages & static_cast<uint8_t>(1u << _flushPage)) {
            _flushMinCol = _dirtyMinCol[_flushPage];
            _flushMaxCol = _dirtyMaxCol[_flushPage];
            if (_flushMaxCol >= _flushMinCol) {
              _flushPageGeneration = _dirtyGeneration[_flushPage];
              _flushState = FlushState::SET_COL_ADDR;
              found = true;
              break;
            }
          }
          _flushPage++;
        }

        if (!found) {
          _flushState = FlushState::DONE;
          if (!_inPageIteration) {
            _updateHealth(Ok());
            _flushAccounted = true;
          }
          return Ok();
        }
        break;
      }

      default:
        return Ok();
    }
  }

  if (_flushState == FlushState::DONE) {
    return Ok();
  }
  if (_flushState == FlushState::ERROR) {
    return _flushError.ok() ? Error(Err::INTERNAL_ERROR, "flush failed") : _flushError;
  }
  return Error(Err::IN_PROGRESS, "flush in progress");
}

// ============================================================================
// Flush control
// ============================================================================

Status SSD1315::requestFlush() {
  if (!_initialized) {
    return Error(Err::NOT_INITIALIZED, "not initialized");
  }
  if (_driverState == DriverState::OFFLINE) {
    return _offlineStatus();
  }

  // If caller requests a new flush before tick() consumes terminal state,
  // account it now to keep health tracking exact.
  if (_flushState == FlushState::DONE) {
    if (!_flushAccounted) {
      _updateHealth(Ok());
    }
    _flushAccounted = false;
    _flushState = FlushState::IDLE;
  } else if (_flushState == FlushState::ERROR) {
    Status flushFailure =
        _flushError.ok() ? Error(Err::INTERNAL_ERROR, "flush failed") : _flushError;
    if (!_flushAccounted) {
      _updateHealth(flushFailure);
    }
    _flushError = flushFailure;
    _flushAccounted = false;
    _flushState = FlushState::IDLE;
  }

  if (_flushState == FlushState::SET_COL_ADDR ||
      _flushState == FlushState::SET_PAGE_ADDR ||
      _flushState == FlushState::SEND_DATA) {
    return Error(Err::BUSY, "flush in progress");
  }

  // Find first dirty page
  if (_dirtyPages == 0) {
    _flushState = FlushState::IDLE;
    return Ok();
  }
  if (_scrollActive) {
    return Error(Err::STATE_ERROR, "scroll active; stop scroll before flushing GDDRAM");
  }

  bool foundFirst = false;
  for (uint8_t p = 0; p < _totalPages; p++) {
    if (!(_dirtyPages & static_cast<uint8_t>(1u << p))) {
      continue;
    }

    if (_dirtyMinCol[p] >= _config.width || _dirtyMaxCol[p] < _dirtyMinCol[p]) {
      // Sanitize inconsistent dirty metadata instead of issuing invalid windows.
      _dirtyPages &= static_cast<uint8_t>(~(1u << p));
      _dirtyMinCol[p] = 0xFF;
      _dirtyMaxCol[p] = 0x00;
      continue;
    }

    _flushPage = p;
    _flushMinCol = _dirtyMinCol[p];
    _flushMaxCol = _dirtyMaxCol[p];
    _flushPageGeneration = _dirtyGeneration[p];
    foundFirst = true;
    break;
  }

  if (!foundFirst) {
    _flushState = FlushState::IDLE;
    return Ok();
  }

  _flushEndPage = _flushPage;

  // Find last dirty page
  for (int16_t p = static_cast<int16_t>(_totalPages) - 1;
       p >= static_cast<int16_t>(_flushPage); p--) {
    if ((_dirtyPages & static_cast<uint8_t>(1u << p)) &&
        _dirtyMinCol[p] < _config.width &&
        _dirtyMaxCol[p] >= _dirtyMinCol[p]) {
      _flushEndPage = static_cast<uint8_t>(p);
      break;
    }
  }

  _flushState = FlushState::SET_COL_ADDR;
  _flushStarted = false;  // Timer latches on first tick()/pollFlush() caller timestamp.
  _flushAccounted = false;
  _flushError = Ok();

  return Ok();
}

Status SSD1315::requestFlushRect(int16_t x, int16_t y, int16_t w, int16_t h) {
  if (!_initialized) {
    return Error(Err::NOT_INITIALIZED, "not initialized");
  }
  if (_driverState == DriverState::OFFLINE) {
    return _offlineStatus();
  }

  if (_flushState == FlushState::DONE) {
    if (!_flushAccounted) {
      _updateHealth(Ok());
    }
    _flushAccounted = false;
    _flushState = FlushState::IDLE;
  } else if (_flushState == FlushState::ERROR) {
    Status flushFailure =
        _flushError.ok() ? Error(Err::INTERNAL_ERROR, "flush failed") : _flushError;
    if (!_flushAccounted) {
      _updateHealth(flushFailure);
    }
    _flushError = flushFailure;
    _flushAccounted = false;
    _flushState = FlushState::IDLE;
  }

  if (_flushState == FlushState::SET_COL_ADDR ||
      _flushState == FlushState::SET_PAGE_ADDR ||
      _flushState == FlushState::SEND_DATA) {
    return Error(Err::BUSY, "flush in progress");
  }

  if (w <= 0 || h <= 0) {
    _flushState = FlushState::IDLE;
    return Ok();
  }

  // Clip using widened math to avoid signed int16 overflow/underflow.
  int32_t x0 = x;
  int32_t y0 = y;
  int32_t x1 = static_cast<int32_t>(x) + static_cast<int32_t>(w) - 1;
  int32_t y1 = static_cast<int32_t>(y) + static_cast<int32_t>(h) - 1;

  if (x0 < 0) x0 = 0;
  if (y0 < 0) y0 = 0;
  if (x1 >= _config.width) x1 = _config.width - 1;
  if (y1 >= _config.height) y1 = _config.height - 1;

  if (x0 > x1 || y0 > y1) {
    _flushState = FlushState::IDLE;
    return Ok();
  }

  // Mark pages as dirty
  uint8_t startPage = static_cast<uint8_t>(y0 / 8);
  uint8_t endPage = static_cast<uint8_t>(y1 / 8);
  uint8_t startCol = static_cast<uint8_t>(x0);
  uint8_t endCol = static_cast<uint8_t>(x1);

  for (uint8_t p = startPage; p <= endPage; p++) {
    markDirty(p, startCol, endCol);
  }

  return requestFlush();
}

bool SSD1315::isFlushing() const {
  return _flushState == FlushState::SET_COL_ADDR ||
         _flushState == FlushState::SET_PAGE_ADDR ||
         _flushState == FlushState::SEND_DATA;
}

FlushStatus SSD1315::getFlushStatus() const {
  FlushStatus out;
  switch (_flushState) {
    case FlushState::SET_COL_ADDR:
      out.phase = FlushPhase::SET_COL_ADDR;
      break;
    case FlushState::SET_PAGE_ADDR:
      out.phase = FlushPhase::SET_PAGE_ADDR;
      break;
    case FlushState::SEND_DATA:
      out.phase = FlushPhase::SEND_DATA;
      break;
    case FlushState::DONE:
      out.phase = FlushPhase::DONE;
      break;
    case FlushState::ERROR:
      out.phase = FlushPhase::ERROR;
      break;
    case FlushState::IDLE:
    default:
      out.phase = FlushPhase::IDLE;
      break;
  }

  out.inProgress = isFlushing();
  out.dirtyPages = _dirtyPages;
  out.currentPage = _flushPage;
  out.endPage = _flushEndPage;
  out.currentColumn = _flushCol;
  out.minColumn = _flushMinCol;
  out.maxColumn = _flushMaxCol;
  out.lastError = (_flushState == FlushState::ERROR) ? _flushError : _lastError;
  return out;
}

Status SSD1315::waitFlush(uint32_t nowMs, uint32_t timeoutMs) {
  if (!_initialized) {
    return Error(Err::NOT_INITIALIZED, "not initialized");
  }
  if (_driverState == DriverState::OFFLINE) {
    return _offlineStatus();
  }

  if (timeoutMs == 0) {
    timeoutMs = _config.flushTimeoutMs;
  }
  if (timeoutMs == 0) {
    timeoutMs = 5000;  // Default 5s
  }

  // Use caller-provided timestamp when available; otherwise sample the hook.
  // If no hook is configured, keep the caller timestamp as the wait clock so
  // unsigned elapsed math does not underflow from nowMs -> 0.
  const bool hasTimeHook = (_config.nowMs != nullptr);
  uint32_t start = nowMs;
  if (start == 0) {
    start = _nowMs();
  }
  uint32_t lastObservedMs = start;
  uint32_t stalledIterations = 0;
  const uint32_t maxStalledIterations =
      waitFlushStallGuardIterations(timeoutMs, _config.i2cTimeoutMs);

  // Wait for power-on delay AND flush to complete.
  // Uses unsigned subtraction which is safe across 32-bit clock rollover.
  while (isFlushing() || (!_sleeping && _powerState != PowerState::READY)) {
    uint32_t currentMs = hasTimeHook ? _nowMs() : start;
    tick(currentMs);

    // Unsigned subtraction handles 32-bit clock rollover correctly.
    uint32_t elapsed = currentMs - start;
    if (elapsed >= timeoutMs) {
      if (isFlushing()) {
        // Abort active flush and account failure exactly once.
        _flushError = Error(Err::TIMEOUT, "waitFlush timeout");
        _lastError = _flushError;
        _flushState = FlushState::ERROR;
        _updateHealth(_flushError);
        _flushState = FlushState::IDLE;
      }
      return Error(Err::TIMEOUT, "waitFlush timeout");
    }

    if (currentMs == lastObservedMs) {
      if (++stalledIterations >= maxStalledIterations) {
        if (isFlushing()) {
          _flushError = Error(Err::TIMEOUT, "waitFlush time stalled");
          _lastError = _flushError;
          _flushState = FlushState::ERROR;
          _updateHealth(_flushError);
          _flushState = FlushState::IDLE;
        }
        return Error(Err::TIMEOUT, "waitFlush time stalled");
      }
    } else {
      lastObservedMs = currentMs;
      stalledIterations = 0;
    }

    // yield() gives the FreeRTOS scheduler a chance to run other tasks and
    // feeds the WDT. It maps to vTaskDelay(1) on ESP32 Arduino, which is
    // distinct from delay() — it yields once rather than blocking for a set
    // duration. This prevents watchdog resets in tight loops without adding
    // fixed latency. Safe to call from loop() context.
    _cooperativeYield();
  }

  // Flush may have reached terminal state in the final tick() above.
  if (_flushState == FlushState::DONE) {
    if (!_flushAccounted) {
      _updateHealth(Ok());
    }
    _flushAccounted = false;
    _flushState = FlushState::IDLE;
  } else if (_flushState == FlushState::ERROR) {
    Status flushFailure =
        _flushError.ok() ? Error(Err::INTERNAL_ERROR, "flush failed") : _flushError;
    if (!_flushAccounted) {
      _updateHealth(flushFailure);
    }
    _flushError = flushFailure;
    _flushAccounted = false;
    _flushState = FlushState::IDLE;
    return flushFailure;
  }

  return Ok();
}

// ============================================================================
// Buffer helpers
// ============================================================================

size_t SSD1315::bufferIndex(int16_t x, int16_t y) const {
  // In page buffer mode, y is relative to current buffer page
  uint8_t page = (y / 8) % _config.pageBufferPages;
  return x + static_cast<size_t>(page) * _config.width;
}

uint8_t SSD1315::bufferBit(int16_t y) const {
  return 1 << (y & 7);
}

bool SSD1315::isInBuffer(int16_t x, int16_t y) const {
  if (!_initialized || _buffer == nullptr) {
    return false;
  }
  if (x < 0 || x >= _config.width || y < 0 || y >= _config.height) {
    return false;
  }
  // In page buffer mode, check if y is in current buffer range
  if (isPageBufferMode()) {
    uint8_t page = y / 8;
    uint8_t bufferStartPage = _currentBufferPage * _config.pageBufferPages;
    uint8_t bufferEndPage = bufferStartPage + _config.pageBufferPages - 1;
    return page >= bufferStartPage && page <= bufferEndPage;
  }
  return true;
}

size_t SSD1315::getBufferSize() const {
  if (!_initialized) return 0;
  return static_cast<size_t>(_config.width) * _config.pageBufferPages;
}

/**
 * @brief Mark a page (column range) in the frame buffer as dirty.
 *
 * In page buffer mode, this function only affects pages that fall within the
 * currently loaded page-buffer window. If @p page is outside the current
 * window, the call is intentionally ignored and no dirty state is recorded.
 * The caller is responsible for invoking markDirty again when that page is
 * present in the active buffer.
 */
void SSD1315::markDirty(uint8_t page, uint8_t minCol, uint8_t maxCol) {
  if (page >= _totalPages) return;
  if (isPageBufferMode()) {
    uint8_t bufferStartPage = _currentBufferPage * _config.pageBufferPages;
    uint8_t bufferEndPage = bufferStartPage + _config.pageBufferPages - 1;
    if (page < bufferStartPage || page > bufferEndPage) {
      return;
    }
  }
  if (maxCol >= _config.width) maxCol = _config.width - 1;
  if (minCol > maxCol) return;

  _dirtyPages |= static_cast<uint8_t>(1u << page);
  if (minCol < _dirtyMinCol[page]) _dirtyMinCol[page] = minCol;
  if (maxCol > _dirtyMaxCol[page]) _dirtyMaxCol[page] = maxCol;
  _dirtyGeneration[page]++;
}

void SSD1315::markAllDirty() {
  if (_totalPages == 0) {
    return;
  }

  uint8_t startPage = 0;
  uint8_t endPage = _totalPages - 1;

  if (isPageBufferMode()) {
    startPage = _currentBufferPage * _config.pageBufferPages;
    uint16_t endExclusive = static_cast<uint16_t>(startPage) + _config.pageBufferPages;
    if (endExclusive > _totalPages) {
      endExclusive = _totalPages;
    }
    if (startPage >= endExclusive) {
      return;
    }
    endPage = static_cast<uint8_t>(endExclusive - 1);
  }

  for (uint8_t p = startPage; p <= endPage; p++) {
    _dirtyPages |= static_cast<uint8_t>(1u << p);
    _dirtyMinCol[p] = 0;
    _dirtyMaxCol[p] = _config.width - 1;
    _dirtyGeneration[p]++;
  }
}

void SSD1315::clearDirty() {
  _dirtyPages = 0;
  memset(_dirtyMinCol, 0xFF, sizeof(_dirtyMinCol));
  memset(_dirtyMaxCol, 0x00, sizeof(_dirtyMaxCol));
}

bool SSD1315::isDirty() const {
  return _dirtyPages != 0;
}

// ============================================================================
// Page buffer mode
// ============================================================================

bool SSD1315::isPageBufferMode() const {
  return _initialized && _config.pageBufferPages < _totalPages;
}

void SSD1315::firstPage() {
  if (!_initialized) return;

  memset(_buffer, 0, getBufferSize());
  _currentBufferPage = 0;
  _inPageIteration = true;
  clearDirty();

  resetActivityTimer(_nowMs());
  wakeIfSleeping();
}

bool SSD1315::nextPage() {
  if (!_initialized || !_inPageIteration) return false;

  if (_driverState == DriverState::OFFLINE) {
    _lastError = _offlineStatus();
    _inPageIteration = false;
    return false;
  }

  // If flush is still in progress, return true (more work to do)
  // Caller should call tick() and try again
  if (isFlushing()) {
    return true;
  }

  // Check if previous flush failed
  if (_flushState == FlushState::ERROR) {
    Status flushFailure =
        _flushError.ok() ? Error(Err::INTERNAL_ERROR, "flush failed") : _flushError;
    _updateHealth(flushFailure);
    _flushError = flushFailure;
    _flushState = FlushState::IDLE;
    _inPageIteration = false;
    return false;  // Caller should check lastError()
  }

  // If this is NOT the first call (i.e., we've already flushed at least once),
  // advance to next page set
  if (_flushState == FlushState::DONE) {
    _updateHealth(Ok());
    _currentBufferPage++;
    uint8_t nextDisplayPage = _currentBufferPage * _config.pageBufferPages;

    if (nextDisplayPage >= _totalPages) {
      // Iteration complete
      _inPageIteration = false;
      _currentBufferPage = 0;
      _flushState = FlushState::IDLE;
      return false;
    }

    // Clear buffer for next page and reset flush state
    memset(_buffer, 0, getBufferSize());
    clearDirty();
    _flushState = FlushState::IDLE;
    return true;  // More pages - caller should draw and call nextPage() again
  }

  // Mark current buffer pages as dirty and request flush (non-blocking)
  for (uint8_t p = 0; p < _config.pageBufferPages; p++) {
    uint8_t displayPage = _currentBufferPage * _config.pageBufferPages + p;
    if (displayPage < _totalPages) {
      markDirty(displayPage, 0, _config.width - 1);
    }
  }

  // Start async flush - actual transfer happens in tick()
  Status st = requestFlush();
  if (!st.ok() && st.code != Err::BUSY) {
    _lastError = st;  // Immediate diagnostics for page iteration errors
    _inPageIteration = false;
    return false;
  }

  return true;  // Flush started - caller should call tick() and nextPage() again
}

int16_t SSD1315::pageBufferYOffset() const {
  if (!_initialized) return 0;
  return _currentBufferPage * _config.pageBufferPages * 8;
}

// ============================================================================
// Drawing primitives
// ============================================================================

void SSD1315::clear() {
  if (!_initialized || _buffer == nullptr) return;

  memset(_buffer, 0, getBufferSize());
  markAllDirty();
  resetActivityTimer(_nowMs());
  wakeIfSleeping();
}

void SSD1315::fill() {
  if (!_initialized || _buffer == nullptr) return;

  memset(_buffer, 0xFF, getBufferSize());
  markAllDirty();
  resetActivityTimer(_nowMs());
  wakeIfSleeping();
}

void SSD1315::setPixel(int16_t x, int16_t y, bool on) {
  if (!_initialized || _buffer == nullptr) return;
  if (!isInBuffer(x, y)) return;

  // Adjust y for page buffer mode
  int16_t bufY = y;
  if (isPageBufferMode()) {
    int16_t offset = pageBufferYOffset();
    bufY = y - offset;
    if (bufY < 0 || bufY >= _config.pageBufferPages * 8) return;
  }

  size_t idx = bufferIndex(x, bufY);
  uint8_t bit = bufferBit(bufY);

  if (on) {
    _buffer[idx] |= bit;
  } else {
    _buffer[idx] &= ~bit;
  }

  markDirty(y / 8, x, x);
  resetActivityTimer(_nowMs());
  wakeIfSleeping();
}

bool SSD1315::getPixel(int16_t x, int16_t y) const {
  if (!_initialized || _buffer == nullptr) return false;
  if (!isInBuffer(x, y)) return false;

  int16_t bufY = y;
  if (isPageBufferMode()) {
    int16_t offset = pageBufferYOffset();
    bufY = y - offset;
    if (bufY < 0 || bufY >= _config.pageBufferPages * 8) return false;
  }

  size_t idx = bufferIndex(x, bufY);
  uint8_t bit = bufferBit(bufY);
  return (_buffer[idx] & bit) != 0;
}

void SSD1315::drawHLine(int16_t x, int16_t y, int16_t w, bool on) {
  if (!_initialized || _buffer == nullptr || w <= 0) return;
  if (y < 0 || y >= _config.height) return;

  int32_t x0 = x;
  int32_t x1 = static_cast<int32_t>(x) + static_cast<int32_t>(w) - 1;

  if (x1 < 0 || x0 >= _config.width) return;
  if (x0 < 0) x0 = 0;
  if (x1 >= _config.width) x1 = _config.width - 1;

  // Write directly to the buffer for efficiency, then mark dirty once.
  int16_t bufY = static_cast<int16_t>(y);
  if (isPageBufferMode()) {
    bufY = static_cast<int16_t>(y - pageBufferYOffset());
    if (bufY < 0 || bufY >= _config.pageBufferPages * 8) return;
  }
  uint8_t bit = bufferBit(bufY);
  for (int32_t xi = x0; xi <= x1; xi++) {
    size_t idx = bufferIndex(static_cast<int16_t>(xi), bufY);
    if (on) {
      _buffer[idx] |= bit;
    } else {
      _buffer[idx] &= ~bit;
    }
  }
  markDirty(static_cast<uint8_t>(y / 8),
            static_cast<uint8_t>(x0),
            static_cast<uint8_t>(x1));
  resetActivityTimer(_nowMs());
  wakeIfSleeping();
}

void SSD1315::drawVLine(int16_t x, int16_t y, int16_t h, bool on) {
  if (!_initialized || _buffer == nullptr || h <= 0) return;
  if (x < 0 || x >= _config.width) return;

  int32_t y0 = y;
  int32_t y1 = static_cast<int32_t>(y) + static_cast<int32_t>(h) - 1;

  if (y1 < 0 || y0 >= _config.height) return;
  if (y0 < 0) y0 = 0;
  if (y1 >= _config.height) y1 = _config.height - 1;

  // Write directly to the buffer for efficiency, then mark dirty once per page.
  for (int32_t yi = y0; yi <= y1; yi++) {
    int16_t bufY = static_cast<int16_t>(yi);
    if (isPageBufferMode()) {
      bufY = static_cast<int16_t>(yi - pageBufferYOffset());
      if (bufY < 0 || bufY >= _config.pageBufferPages * 8) continue;
    }
    size_t idx = bufferIndex(x, bufY);
    uint8_t bit = bufferBit(bufY);
    if (on) {
      _buffer[idx] |= bit;
    } else {
      _buffer[idx] &= ~bit;
    }
  }
  // Mark all touched pages dirty in one pass.
  uint8_t startPage = static_cast<uint8_t>(y0 / 8);
  uint8_t endPage   = static_cast<uint8_t>(y1 / 8);
  for (uint8_t p = startPage; p <= endPage; p++) {
    markDirty(p, static_cast<uint8_t>(x), static_cast<uint8_t>(x));
  }
  resetActivityTimer(_nowMs());
  wakeIfSleeping();
}

void SSD1315::drawRect(int16_t x, int16_t y, int16_t w, int16_t h, bool on) {
  if (!_initialized || _buffer == nullptr || w <= 0 || h <= 0) return;

  int32_t x0 = x;
  int32_t y0 = y;
  int32_t x1 = static_cast<int32_t>(x) + static_cast<int32_t>(w) - 1;
  int32_t y1 = static_cast<int32_t>(y) + static_cast<int32_t>(h) - 1;

  if (x1 < 0 || y1 < 0 || x0 >= _config.width || y0 >= _config.height) return;

  if (x0 < 0) x0 = 0;
  if (y0 < 0) y0 = 0;
  if (x1 >= _config.width) x1 = _config.width - 1;
  if (y1 >= _config.height) y1 = _config.height - 1;

  int16_t clippedW = static_cast<int16_t>(x1 - x0 + 1);
  int16_t clippedH = static_cast<int16_t>(y1 - y0 + 1);
  int16_t xStart = static_cast<int16_t>(x0);
  int16_t yStart = static_cast<int16_t>(y0);
  int16_t xEnd = static_cast<int16_t>(x1);
  int16_t yEnd = static_cast<int16_t>(y1);

  drawHLine(xStart, yStart, clippedW, on);
  if (yEnd != yStart) {
    drawHLine(xStart, yEnd, clippedW, on);
  }
  drawVLine(xStart, yStart, clippedH, on);
  if (xEnd != xStart) {
    drawVLine(xEnd, yStart, clippedH, on);
  }
}

void SSD1315::fillRect(int16_t x, int16_t y, int16_t w, int16_t h, bool on) {
  if (!_initialized || _buffer == nullptr || w <= 0 || h <= 0) return;

  int32_t x0 = x;
  int32_t y0 = y;
  int32_t x1 = static_cast<int32_t>(x) + static_cast<int32_t>(w) - 1;
  int32_t y1 = static_cast<int32_t>(y) + static_cast<int32_t>(h) - 1;

  if (x1 < 0 || y1 < 0 || x0 >= _config.width || y0 >= _config.height) return;

  if (x0 < 0) x0 = 0;
  if (y0 < 0) y0 = 0;
  if (x1 >= _config.width) x1 = _config.width - 1;
  if (y1 >= _config.height) y1 = _config.height - 1;

  // Write directly to the buffer for all rows, then mark dirty once.
  for (int32_t yi = y0; yi <= y1; yi++) {
    int16_t bufY = static_cast<int16_t>(yi);
    if (isPageBufferMode()) {
      bufY = static_cast<int16_t>(yi - pageBufferYOffset());
      if (bufY < 0 || bufY >= _config.pageBufferPages * 8) continue;
    }
    uint8_t bit = bufferBit(bufY);
    for (int32_t xi = x0; xi <= x1; xi++) {
      size_t idx = bufferIndex(static_cast<int16_t>(xi), bufY);
      if (on) {
        _buffer[idx] |= bit;
      } else {
        _buffer[idx] &= ~bit;
      }
    }
  }
  // Mark affected pages dirty in one pass.
  uint8_t startPage = static_cast<uint8_t>(y0 / 8);
  uint8_t endPage   = static_cast<uint8_t>(y1 / 8);
  for (uint8_t p = startPage; p <= endPage; p++) {
    markDirty(p, static_cast<uint8_t>(x0), static_cast<uint8_t>(x1));
  }
  resetActivityTimer(_nowMs());
  wakeIfSleeping();
}

void SSD1315::drawLine(int16_t x0, int16_t y0, int16_t x1, int16_t y1, bool on) {
  if (!_initialized || _buffer == nullptr) return;

  int32_t x0c = x0;
  int32_t y0c = y0;
  int32_t x1c = x1;
  int32_t y1c = y1;

  const int32_t xMin = 0;
  const int32_t yMin = 0;
  const int32_t xMax = _config.width - 1;
  const int32_t yMax = _config.height - 1;

  // Cohen-Sutherland clipping keeps Bresenham bounded to display geometry.
  uint8_t code0 = outCode(x0c, y0c, xMin, yMin, xMax, yMax);
  uint8_t code1 = outCode(x1c, y1c, xMin, yMin, xMax, yMax);

  // Guard: each iteration clips at least one endpoint; max 4 clip boundaries,
  // so ≤ 4 iterations are sufficient. Extra iterations indicate a degenerate
  // case from integer rounding — bail out safely.
  uint8_t clipIter = 0;
  while (true) {
    if ((code0 | code1) == 0) {
      break;  // Fully inside
    }
    if ((code0 & code1) || clipIter >= 4) {
      return;  // Fully outside, or degenerate clipping — abort
    }
    clipIter++;

    uint8_t codeOut = (code0 != 0) ? code0 : code1;
    int32_t xNew = 0;
    int32_t yNew = 0;

    if (codeOut & OUT_TOP) {
      if (y1c == y0c) return;
      xNew = x0c + (x1c - x0c) * (yMin - y0c) / (y1c - y0c);
      yNew = yMin;
    } else if (codeOut & OUT_BOTTOM) {
      if (y1c == y0c) return;
      xNew = x0c + (x1c - x0c) * (yMax - y0c) / (y1c - y0c);
      yNew = yMax;
    } else if (codeOut & OUT_RIGHT) {
      if (x1c == x0c) return;
      yNew = y0c + (y1c - y0c) * (xMax - x0c) / (x1c - x0c);
      xNew = xMax;
    } else {  // OUT_LEFT
      if (x1c == x0c) return;
      yNew = y0c + (y1c - y0c) * (xMin - x0c) / (x1c - x0c);
      xNew = xMin;
    }

    if (codeOut == code0) {
      x0c = xNew;
      y0c = yNew;
      code0 = outCode(x0c, y0c, xMin, yMin, xMax, yMax);
    } else {
      x1c = xNew;
      y1c = yNew;
      code1 = outCode(x1c, y1c, xMin, yMin, xMax, yMax);
    }
  }

  // Bresenham's line algorithm
  int32_t dx = (x1c > x0c) ? (x1c - x0c) : (x0c - x1c);
  int32_t dy = (y1c > y0c) ? (y1c - y0c) : (y0c - y1c);
  int32_t sx = (x0c < x1c) ? 1 : -1;
  int32_t sy = (y0c < y1c) ? 1 : -1;
  int32_t err = dx - dy;

  while (true) {
    setPixel(static_cast<int16_t>(x0c), static_cast<int16_t>(y0c), on);
    if (x0c == x1c && y0c == y1c) break;
    int32_t e2 = 2 * err;
    if (e2 > -dy) {
      err -= dy;
      x0c += sx;
    }
    if (e2 < dx) {
      err += dx;
      y0c += sy;
    }
  }
}

void SSD1315::drawCircle(int16_t cx, int16_t cy, int16_t r, bool on) {
  if (!_initialized || _buffer == nullptr || r < 0) return;
  if (r == 0) {
    setPixel(cx, cy, on);
    return;
  }

  // Keep work bounded even for pathological input radii.
  const int16_t maxRadius = static_cast<int16_t>(_config.width + _config.height);
  if (r > maxRadius) {
    r = maxRadius;
  }

  if (cx + r < 0 || cy + r < 0 ||
      cx - r >= _config.width || cy - r >= _config.height) {
    return;
  }

  // Midpoint circle algorithm
  // Use int32_t for err/x/y to avoid int16_t overflow for large radii.
  int32_t x = r;
  int32_t y = 0;
  int32_t err = 0;

  while (x >= y) {
    setPixel(static_cast<int16_t>(cx + x), static_cast<int16_t>(cy + y), on);
    setPixel(static_cast<int16_t>(cx + y), static_cast<int16_t>(cy + x), on);
    setPixel(static_cast<int16_t>(cx - y), static_cast<int16_t>(cy + x), on);
    setPixel(static_cast<int16_t>(cx - x), static_cast<int16_t>(cy + y), on);
    setPixel(static_cast<int16_t>(cx - x), static_cast<int16_t>(cy - y), on);
    setPixel(static_cast<int16_t>(cx - y), static_cast<int16_t>(cy - x), on);
    setPixel(static_cast<int16_t>(cx + y), static_cast<int16_t>(cy - x), on);
    setPixel(static_cast<int16_t>(cx + x), static_cast<int16_t>(cy - y), on);

    y++;
    err += 1 + 2 * y;
    if (2 * (err - x) + 1 > 0) {
      x--;
      err += 1 - 2 * x;
    }
  }
}

void SSD1315::fillCircle(int16_t cx, int16_t cy, int16_t r, bool on) {
  if (!_initialized || _buffer == nullptr || r < 0) return;
  if (r == 0) {
    setPixel(cx, cy, on);
    return;
  }

  const int16_t maxRadius = static_cast<int16_t>(_config.width + _config.height);
  if (r > maxRadius) {
    r = maxRadius;
  }

  if (cx + r < 0 || cy + r < 0 ||
      cx - r >= _config.width || cy - r >= _config.height) {
    return;
  }

  drawVLine(cx, cy - r, 2 * r + 1, on);

  // Use int32_t for err/x/y to avoid int16_t overflow for large radii.
  int32_t x = r;
  int32_t y = 0;
  int32_t err = 0;

  while (x >= y) {
    drawVLine(static_cast<int16_t>(cx + x), static_cast<int16_t>(cy - y), static_cast<int16_t>(2 * y + 1), on);
    drawVLine(static_cast<int16_t>(cx + y), static_cast<int16_t>(cy - x), static_cast<int16_t>(2 * x + 1), on);
    drawVLine(static_cast<int16_t>(cx - y), static_cast<int16_t>(cy - x), static_cast<int16_t>(2 * x + 1), on);
    drawVLine(static_cast<int16_t>(cx - x), static_cast<int16_t>(cy - y), static_cast<int16_t>(2 * y + 1), on);

    y++;
    err += 1 + 2 * y;
    if (2 * (err - x) + 1 > 0) {
      x--;
      err += 1 - 2 * x;
    }
  }
}

void SSD1315::drawBitmap(int16_t x, int16_t y, const uint8_t* bitmap,
                          int16_t w, int16_t h, bool on) {
  if (!_initialized || _buffer == nullptr ||
      bitmap == nullptr || w <= 0 || h <= 0) return;

  int32_t x0 = x;
  int32_t y0 = y;
  int32_t x1 = static_cast<int32_t>(x) + static_cast<int32_t>(w) - 1;
  int32_t y1 = static_cast<int32_t>(y) + static_cast<int32_t>(h) - 1;

  if (x1 < 0 || y1 < 0 || x0 >= _config.width || y0 >= _config.height) {
    return;
  }

  if (x0 < 0) x0 = 0;
  if (y0 < 0) y0 = 0;
  if (x1 >= _config.width) x1 = _config.width - 1;
  if (y1 >= _config.height) y1 = _config.height - 1;

  const int32_t byteWidth = (static_cast<int32_t>(w) + 7) / 8;

  for (int32_t j = y0; j <= y1; j++) {
    int32_t srcY = j - y;
    const uint8_t* bmpRow = bitmap + static_cast<size_t>(srcY) * static_cast<size_t>(byteWidth);

    int16_t bufY = static_cast<int16_t>(j);
    if (isPageBufferMode()) {
      bufY = static_cast<int16_t>(j - pageBufferYOffset());
      if (bufY < 0 || bufY >= _config.pageBufferPages * 8) continue;
    }
    uint8_t bit = bufferBit(bufY);

    // Hoist the constant page-base offset out of the inner column loop to
    // avoid a division + multiplication per pixel.
    uint8_t page = static_cast<uint8_t>((bufY / 8) % _config.pageBufferPages);
    size_t rowBase = static_cast<size_t>(page) * _config.width;

    for (int32_t i = x0; i <= x1; i++) {
      int32_t srcX = i - x;
      // Get bit from bitmap (MSB first)
      uint8_t bitMask = static_cast<uint8_t>(0x80u >> (srcX & 7));
      if (bmpRow[srcX / 8] & bitMask) {
        size_t idx = rowBase + static_cast<size_t>(i);
        if (on) { _buffer[idx] |= bit; } else { _buffer[idx] &= ~bit; }
      }
    }
  }

  // Mark dirty once for the entire bounding box.
  uint8_t startPage = static_cast<uint8_t>(y0 / 8);
  uint8_t endPage   = static_cast<uint8_t>(y1 / 8);
  for (uint8_t p = startPage; p <= endPage; p++) {
    markDirty(p, static_cast<uint8_t>(x0), static_cast<uint8_t>(x1));
  }
  resetActivityTimer(_nowMs());
  wakeIfSleeping();
}

// ============================================================================
// Text rendering
// ============================================================================

void SSD1315::drawChar(int16_t x, int16_t y, char c, bool on) {
  if (!_initialized || _buffer == nullptr) return;

  uint8_t ch = static_cast<uint8_t>(c);

  // Map to font index
  if (ch < FONT_FIRST_CHAR || ch >= FONT_FIRST_CHAR + FONT_CHAR_COUNT) {
    // Draw replacement character (filled box)
    fillRect(x, y, FONT_WIDTH, FONT_HEIGHT, on);
    return;
  }

  uint8_t idx = ch - FONT_FIRST_CHAR;
  const uint8_t* glyph = &FONT_5X7[static_cast<size_t>(idx) * FONT_WIDTH];

  // Write glyph columns directly for efficiency; markDirty once per character.
  for (uint8_t col = 0; col < FONT_WIDTH; col++) {
    uint8_t colData = glyph[col];
    int16_t px = x + col;
    if (px < 0 || px >= _config.width) continue;

    for (uint8_t row = 0; row < FONT_HEIGHT; row++) {
      int16_t py = y + row;
      if (py < 0 || py >= _config.height) continue;

      int16_t bufY = py;
      if (isPageBufferMode()) {
        bufY = static_cast<int16_t>(py - pageBufferYOffset());
        if (bufY < 0 || bufY >= _config.pageBufferPages * 8) continue;
      }

      size_t bufIdx = bufferIndex(px, bufY);
      uint8_t bit   = bufferBit(bufY);
      if (colData & static_cast<uint8_t>(1u << row)) {
        if (on) { _buffer[bufIdx] |= bit; } else { _buffer[bufIdx] &= ~bit; }
      }
    }
  }

  // Mark the entire character cell dirty in one call.
  int32_t x0 = x; if (x0 < 0) x0 = 0;
  int32_t x1 = static_cast<int32_t>(x) + FONT_WIDTH - 1;
  if (x1 >= _config.width) x1 = _config.width - 1;
  int32_t y0 = y; if (y0 < 0) y0 = 0;
  int32_t y1 = static_cast<int32_t>(y) + FONT_HEIGHT - 1;
  if (y1 >= _config.height) y1 = _config.height - 1;
  if (x0 <= x1 && y0 <= y1) {
    uint8_t startPage = static_cast<uint8_t>(y0 / 8);
    uint8_t endPage   = static_cast<uint8_t>(y1 / 8);
    for (uint8_t p = startPage; p <= endPage; p++) {
      markDirty(p, static_cast<uint8_t>(x0), static_cast<uint8_t>(x1));
    }
  }
  resetActivityTimer(_nowMs());
  wakeIfSleeping();
}

int16_t SSD1315::drawText(int16_t x, int16_t y, const char* str, bool on) {
  if (str == nullptr) return x;
  if (!_initialized || _buffer == nullptr) return x;

  const int32_t startX = x;
  int32_t cursorX = x;
  int32_t cursorY = y;
  size_t processed = 0;
  while (*str != '\0' && processed < TEXT_MAX_CHARS) {
    char c = *str++;
    processed++;

    if (c == '\n') {
      cursorX = startX;
      cursorY += CHAR_HEIGHT;
      continue;
    }

    if (c == '\r') {
      cursorX = startX;
      continue;
    }

    if (cursorX >= INT16_MIN && cursorX <= INT16_MAX &&
        cursorY >= INT16_MIN && cursorY <= INT16_MAX) {
      drawChar(static_cast<int16_t>(cursorX), static_cast<int16_t>(cursorY), c, on);
    }
    cursorX += CHAR_WIDTH;
  }

  resetActivityTimer(_nowMs());
  wakeIfSleeping();
  if (cursorX > INT16_MAX) return INT16_MAX;
  if (cursorX < INT16_MIN) return INT16_MIN;
  return static_cast<int16_t>(cursorX);
}

int16_t SSD1315::getTextWidth(const char* str) {
  if (str == nullptr) return 0;

  // Use int32_t accumulators to avoid int16_t overflow on very long strings.
  int32_t maxWidth = 0;
  int32_t curWidth = 0;

  size_t processed = 0;
  while (*str != '\0' && processed < TEXT_MAX_CHARS) {
    char c = *str++;
    processed++;
    if (c == '\n') {
      if (curWidth > maxWidth) maxWidth = curWidth;
      curWidth = 0;
    } else if (c != '\r') {
      curWidth += CHAR_WIDTH;
    }
  }

  int32_t result = (curWidth > maxWidth) ? curWidth : maxWidth;
  // Clamp to int16_t range (saturating)
  if (result > 32767) result = 32767;
  return static_cast<int16_t>(result);
}

// ============================================================================
// Test patterns
// ============================================================================

void SSD1315::fillCheckerboard(uint8_t size) {
  if (!_initialized || _buffer == nullptr || size == 0) return;

  for (int16_t y = 0; y < _config.height; y++) {
    int16_t bufY = y;
    if (isPageBufferMode()) {
      bufY = static_cast<int16_t>(y - pageBufferYOffset());
      if (bufY < 0 || bufY >= _config.pageBufferPages * 8) continue;
    }
    uint8_t bit = bufferBit(bufY);
    for (int16_t x = 0; x < _config.width; x++) {
      bool on = (static_cast<uint16_t>(x / size) + static_cast<uint16_t>(y / size)) & 1u;
      size_t idx = bufferIndex(x, bufY);
      if (on) {
        _buffer[idx] |= bit;
      } else {
        _buffer[idx] &= ~bit;
      }
    }
  }
  markAllDirty();
  resetActivityTimer(_nowMs());
  wakeIfSleeping();
}

void SSD1315::fillVerticalStripes(uint8_t width) {
  if (!_initialized || _buffer == nullptr || width == 0) return;

  for (int16_t y = 0; y < _config.height; y++) {
    int16_t bufY = y;
    if (isPageBufferMode()) {
      bufY = static_cast<int16_t>(y - pageBufferYOffset());
      if (bufY < 0 || bufY >= _config.pageBufferPages * 8) continue;
    }
    uint8_t bit = bufferBit(bufY);
    for (int16_t x = 0; x < _config.width; x++) {
      bool on = (static_cast<uint16_t>(x / width)) & 1u;
      size_t idx = bufferIndex(x, bufY);
      if (on) {
        _buffer[idx] |= bit;
      } else {
        _buffer[idx] &= ~bit;
      }
    }
  }
  markAllDirty();
  resetActivityTimer(_nowMs());
  wakeIfSleeping();
}

void SSD1315::fillHorizontalStripes(uint8_t height) {
  if (!_initialized || _buffer == nullptr || height == 0) return;

  for (int16_t y = 0; y < _config.height; y++) {
    int16_t bufY = y;
    if (isPageBufferMode()) {
      bufY = static_cast<int16_t>(y - pageBufferYOffset());
      if (bufY < 0 || bufY >= _config.pageBufferPages * 8) continue;
    }
    uint8_t bit = bufferBit(bufY);
    bool on = (static_cast<uint16_t>(y / height)) & 1u;
    for (int16_t x = 0; x < _config.width; x++) {
      size_t idx = bufferIndex(x, bufY);
      if (on) {
        _buffer[idx] |= bit;
      } else {
        _buffer[idx] &= ~bit;
      }
    }
  }
  markAllDirty();
  resetActivityTimer(_nowMs());
  wakeIfSleeping();
}

// ============================================================================
// Hardware scrolling
// ============================================================================

Status SSD1315::startHorizontalScroll(bool left, uint8_t startPage, uint8_t endPage,
                                       ScrollSpeed speed) {
  if (!_initialized) return Error(Err::NOT_INITIALIZED, "not initialized");

  // Validate
  if (_config.width != MAX_WIDTH) {
    return Error(Err::UNSUPPORTED, "hardware scroll requires 128-column panel");
  }
  if (startPage > endPage || endPage >= _totalPages) {
    return Error(Err::INVALID_CONFIG, "invalid page range");
  }
  if (!isValidScrollSpeed(speed)) {
    return Error(Err::INVALID_CONFIG, "invalid scroll speed");
  }

  // Deactivate first
  Status st = sendCommand(cmd::SCROLL_DEACTIVATE);
  if (!st.ok()) {
    _markControlStateDirty(st);
    return st;
  }
  if (_scrollActive) {
    markAllDirty();
  }
  _scrollActive = false;

  // Setup scroll: cmd, dummy, startPage, speed, endPage, dummy, dummy
  uint8_t cmds[7] = {
      left ? cmd::SCROLL_LEFT : cmd::SCROLL_RIGHT,
      cmd::SCROLL_DUMMY,
      startPage,
      static_cast<uint8_t>(speed),
      endPage,
      cmd::SCROLL_COL_START,
      cmd::SCROLL_COL_END};

  st = sendCommandList(cmds, sizeof(cmds));
  if (!st.ok()) {
    _markControlStateDirty(st);
    return st;
  }

  // Activate
  st = sendCommand(cmd::SCROLL_ACTIVATE);
  if (!st.ok()) {
    _markControlStateDirty(st);
  } else {
    _scrollActive = true;
  }
  return st;
}

Status SSD1315::startVerticalScroll(bool left, uint8_t startPage, uint8_t endPage,
                                     ScrollSpeed speed, uint8_t verticalOffset) {
  if (!_initialized) return Error(Err::NOT_INITIALIZED, "not initialized");

  if (_config.width != MAX_WIDTH) {
    return Error(Err::UNSUPPORTED, "hardware scroll requires 128-column panel");
  }
  if (startPage > endPage || endPage >= _totalPages) {
    return Error(Err::INVALID_CONFIG, "invalid page range");
  }
  if (!isValidScrollSpeed(speed)) {
    return Error(Err::INVALID_CONFIG, "invalid scroll speed");
  }
  if (verticalOffset > 63) {
    return Error(Err::INVALID_CONFIG, "verticalOffset must be 0..63");
  }
  if (_verticalScrollRows == 0 || verticalOffset >= _verticalScrollRows) {
    return Error(Err::INVALID_CONFIG, "verticalOffset must be less than scroll area rows");
  }

  Status st = sendCommand(cmd::SCROLL_DEACTIVATE);
  if (!st.ok()) {
    _markControlStateDirty(st);
    return st;
  }
  if (_scrollActive) {
    markAllDirty();
  }
  _scrollActive = false;

  // Setup: cmd, horizontal offset, startPage, speed, endPage,
  // verticalOffset, start column, end column.
  uint8_t cmds[8] = {
      left ? cmd::SCROLL_VERT_LEFT : cmd::SCROLL_VERT_RIGHT,
      cmd::SCROLL_ONE_COL,
      startPage,
      static_cast<uint8_t>(speed),
      endPage,
      verticalOffset,
      cmd::SCROLL_COL_START,
      cmd::SCROLL_COL_END};

  st = sendCommandList(cmds, sizeof(cmds));
  if (!st.ok()) {
    _markControlStateDirty(st);
    return st;
  }

  st = sendCommand(cmd::SCROLL_ACTIVATE);
  if (!st.ok()) {
    _markControlStateDirty(st);
  } else {
    _scrollActive = true;
  }
  return st;
}

Status SSD1315::stopScroll() {
  if (!_initialized) return Error(Err::NOT_INITIALIZED, "not initialized");
  Status st = sendCommand(cmd::SCROLL_DEACTIVATE);
  if (!st.ok()) {
    _markControlStateDirty(st);
  } else {
    if (_scrollActive) {
      markAllDirty();
    }
    _scrollActive = false;
  }
  return st;
}

Status SSD1315::setVerticalScrollArea(uint8_t topFixedRows, uint8_t scrollRows) {
  if (!_initialized) return Error(Err::NOT_INITIALIZED, "not initialized");
  if (scrollRows == 0 ||
      static_cast<uint16_t>(topFixedRows) + scrollRows > _config.height) {
    return Error(Err::INVALID_CONFIG, "invalid scroll area");
  }
  Status st = sendCommand3(cmd::SET_VERT_SCROLL_AREA, topFixedRows, scrollRows);
  if (!st.ok()) {
    _markControlStateDirty(st);
  } else {
    _verticalScrollTopRows = topFixedRows;
    _verticalScrollRows = scrollRows;
  }
  return st;
}

// ============================================================================
// Advanced display features
// ============================================================================

Status SSD1315::setFadeMode(FadeMode mode, uint8_t interval) {
  if (!_initialized) return Error(Err::NOT_INITIALIZED, "not initialized");
  if (!isValidFadeMode(mode)) {
    return Error(Err::INVALID_CONFIG, "invalid fade mode");
  }
  if (interval > 15) {
    return Error(Err::INVALID_CONFIG, "fade interval must be 0..15");
  }
  uint8_t arg = static_cast<uint8_t>(mode) | (interval & 0x0F);
  Status st = sendCommand2(cmd::SET_FADE_BLINK, arg);
  if (!st.ok()) {
    _markControlStateDirty(st);
  }
  return st;
}

Status SSD1315::setZoom(bool enable) {
  if (!_initialized) return Error(Err::NOT_INITIALIZED, "not initialized");
  if (enable && !isAlternativeComPinsConfig(_config.comPins)) {
    return Error(Err::INVALID_CONFIG, "zoom requires alternative COM pins");
  }
  Status st = sendCommand2(cmd::SET_ZOOM, enable ? 0x01 : 0x00);
  if (!st.ok()) {
    _markControlStateDirty(st);
  }
  return st;
}

}  // namespace SSD1315
